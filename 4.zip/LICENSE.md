fecmall 授权协议
=================



在遵循<b>BSD-3-Clause协议</b>的基础上，进行了如下的附加协议：
<br><br>
1.允许个人和公司使用fecmall，在电商项目使用fecmall做二次开发，供自己的公司
业务需求，不需要付费授权，
<b>也不需要</b>在网站底部加上fecmall的链接。

<br>
2.任何基于fecmall做的新产品，必须以fecmall开头命令，譬如fecmall 衣服模板， fecmall facebook登录插件，fecmall fashion theme。

<br>
3.使用fecmall包装成新产品并重新命名是不允许的，任何基于fecmall开发的产品命名必须以fecmall开头，否则就是严重的剽窃行为。
<br><br>
<b>譬如下面是不允许的：</b>
<br><br>
基于fecmall开发了一个电商团购系统，然后命名为 handleShop（后面会说完全自主研发等一堆销售包装话语），并进行包装出售，这种行为是剽窃行为，是不允许的，
<br><br>
<b>正确的做法为：</b>
<br><br>
命名为 fecmall handleShop。
<br><br>

4.任何基于fecmall二开的新产品以及所有的衍生产品，也必须以fecmall开头命名，
并在官网明显位置注明基于fecmall开发，并加上fecmall官网地址，让用户有知情权。


总结：上面的附加，是为了更好的保护fecmall的发展，尊重fecmall的版权，防止不良商家恶搞，包装成各种xx产品说自主研发，剽窃乱搞。

<br><br>
Copyright © 2015 - 2018 fecmall. All Rights Reserved. 

<br><br>
</div>

