# pichain
http://www.fecmall.com/
## Development setup
### MAMP setup
1. Setup ports to 80 (Apache), 81 (nginx) and 3306 (mysql) in your MAMP configuration.
2. Quit your MAMP
3. From CLI type sudo apachectl stop. Use:```sudo apachectl stop``` to stop and use ```ps -A | grep httpd``` to check
4. From CLI type ps -A | grep httpd and you shouldn't see any running process (apart from your grep)
5. Start your MAMP (at this point MAMP should start Apache since 80 port is not in use). Stop your MAMP after you make sure it worked.
6. For Mac, go to ```/Application/MAMP/conf/apache/``` and open ```httpd.conf```, find the line says: ```#Include /Applications/MAMP/conf/apache/extra/httpd-vhosts.conf``` and delete the ```#```. Find the line says: ```AllowOverride None``` and change it to ```AllowOverride All```.
7. Go to ```/Application/MAMP/conf/apache/extra``` and look for ```httpd-vhosts.conf```. You need to replace this file with edited version, if you do not have the edited version, ask it from admin or a developer.
8. Change your phpmyadmin password. ```/Applications/MAMP/Library/bin/mysqladmin -u root -p password [NewPassword]```, the default password is ```root```. After your change the password of phpmyadmin, update the new password to ```/Applications/MAMP/bin/phpMyAdmin/config.inc.php```.
9. Create the database ```pichain```.
10. Under pichain root dir, window：run ```init.bat```, linux: run ```./init```.
11. Once step 1 to 10 done, open your web browser, and go to http://pichain.test/install
12. Click on ```开始fecmall之旅```. Use ```跨境电商模式```.
13. Change ```Mysql数据库名称``` ```fecmall``` to ```pichain```. Put your phpmyadmin password. Then continue.
14. Click on ```进行表格初始化```. Your pichain db should shows dummy data.
15. Click on ```安装产品测试数据``` and ```下一步```.
16. Edit the url to ```pichain.test``` and next.
17. For linux, go to pichain root dir and type ```chmod 644 common/config/main-local.php``` in order to make owner of the file has read and write access, while the group members and other users on the system only have read access for safety issue.
18. Click on ```访问PC商城``` and your local dev environment should be up and run!

### AWS setup
repeat and ```sudo ./init``` and 
```sudo apt-get install php libapache2-mod-php``` and
```sudo a2enmod mpm_prefork && sudo a2enmod php7.0``` and
```sudo service apache2 restart```
Someone format this part!!!!!!
useful link: https://www.digitalocean.com/community/tutorials/how-to-set-up-apache-virtual-hosts-on-ubuntu-18-04-quickstart
