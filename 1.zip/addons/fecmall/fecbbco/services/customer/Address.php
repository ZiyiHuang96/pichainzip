<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */

namespace fecbbco\services\customer;

//use fecshop\models\mysqldb\customer\Address as MyAddress;
use fecshop\services\Service;
use Yii;

/**
 * Address  child services.
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class Address extends \fecshop\services\customer\Address
{
    protected $_addressModelName = '\fecshop\models\mysqldb\customer\Address';
    
    public function setDefaultAddress($customer_id, $address_id)
    {
        // set default
        $updateArr = [];
        $updateArr['updated_at'] = time();
        $updateArr['is_default'] = $this->is_default;
        $updateColumn = $this->_addressModel->updateAll(
            $updateArr,
            [
                'and',
                ['customer_id' => $customer_id],
                ['address_id' => $address_id],
            ]
        );
        if (empty($updateColumn)) {
            Yii::$service->helper->errors->add('customer:{customer_id} set default address:{address_id} fail', ['customer_id' => $customer_id, 'address_id' => $address_id]);
            
            return false;
        }
        
        $updateArr = [];
        $updateArr['updated_at'] = time();
        $updateArr['is_default'] = $this->is_not_default;
        $updateColumn = $this->_addressModel->updateAll(
            $updateArr,
            [
                'and',
                ['customer_id' => $customer_id],
                ['is_default' => $this->is_default],
                ['not in', 'address_id', [$address_id]],
            ]
        );
        
        return true;
    }
}
