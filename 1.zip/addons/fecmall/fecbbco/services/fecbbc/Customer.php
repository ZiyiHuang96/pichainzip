<?php

/*
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace fecbbco\services\fecbdc;

use Yii;
use yii\web\IdentityInterface;

class Customer extends \fecbbc\services\Customer
{
    
    protected $_customerRegisterModelName = '\fecbbco\models\mysqldb\customer\CustomerRegister';
    protected $_customerModelName = '\fecbbc\models\mysqldb\Customer';
    protected $_customerLoginModelName = '\fecshop\models\mysqldb\customer\CustomerLogin';
    
    /**
     * @param array $data
     *
     * example:
     *
     * ```php
     * $data = ['email' => 'user@example.com', 'password' => 'your password'];
     * $loginStatus = \Yii::$service->customer->login($data);
     * ```
     *
     * @return bool
     */
    public function login($data)
    {
        $model = $this->_customerLoginModel;
        $model->password = $data['password'];
        $model->email = $data['email'];
        $loginStatus = $model->login();
        $errors = $model->errors;
        if (empty($errors)) {
            // 合并购物车数据
            Yii::$service->cart->mergeCartAfterUserLogin();
            // 发送登录信息到trace系统
            Yii::$service->page->trace->sendTraceLoginInfoByApi($data['email']);
        } else {
            Yii::$service->helper->errors->addByModelErrors($errors);
        }

        return $loginStatus;
    }
    
    
}