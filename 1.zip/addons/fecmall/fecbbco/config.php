<?php
/**
 * Fecmall Addons Config File
 */

// set namespace alisa
Yii::setAlias('@fecbbco', dirname(dirname(dirname(__DIR__))).'/addons/fecmall/fecbbco/');

return [
    // 插件信息
    'info'  => [
        'name' => 'fecbbco',
        'author' => 'Fecmall',
    ],
    // 插件管理部分
    'administer' => [
        'install' => [
            'class' => 'fecbbco\administer\Install',
            // 其他引入的属性，类似yii2组件的方式写入即可
            'test' => 'test_data',
        ],
        'upgrade' => [
            'class' => 'fecbbco\administer\Upgrade',
        ],
        'uninstall' => [
            'class' => 'fecbbco\administer\Uninstall',
        ],
    ], 
    // 各个入口的配置
    'app' => [
        // 公共层部分配置
        'common' => [
            'enable' => true,
            // 公用层的具体配置下载下面
            'config' => [
                // 重写model和block
                'fecRewriteMap' => [
                    //'\fecshop\models\mysqldb\Product'  => '\fecbbco\models\mysqldb\Product',
                    '\fecshop\models\mysqldb\customer\CustomerRegister'  => '\fecbbco\models\mysqldb\customer\CustomerRegister',
                    '\fecshop\models\mysqldb\customer\CustomerLogin'  => '\fecbbco\models\mysqldb\customer\CustomerLogin',
                    '\fecshop\models\mysqldb\Customer'  => '\fecbbco\models\mysqldb\Customer',
                    // '\fecshop\app\appfront\modules\Customer\block\address\Edit'  => '\fectb\app\appfront\modules\Customer\block\address\Edit',
                ],
                'services' => [
                    'customer' => [
                        'class' => 'fecbbco\services\fecbdc\Customer',
                        'childService' => [
                            'address' => [
                                'class' => 'fecbbco\services\customer\Address',
                            ],
                        ],
                    ],
                    //'cart' => [
                    //    'class' => 'fecshop\rediscart\services\Cart',
                    //    'childService' => [
                    //        'quote' => [
                    //            'class' => 'fecshop\rediscart\services\cart\Quote',
                    //        ],
                    //        'quoteItem' => [
                    //            'class' => 'fecshop\rediscart\services\cart\QuoteItem',
                    //        ],
                    //    ]
                    //]
                ],
            ]
        ],
        // 1.appfront层
        'appfront' => [
            // appfront入口的开关，如果false，则会失效
            'enable' => true,
            'config' => [
                // yii class rewrite map
                'yiiClassMap' => [
                    // 'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',
                ],
                // 重写model和block
                'fecRewriteMap' => [
                    // '\fecshop\app\appfront\modules\Cms\block\home\Index'  => '\fectfurnilife\app\appfront\modules\Cms\block\home\Index',
                    // '\fecshop\app\appfront\modules\Customer\block\address\Edit'  => '\fectfurnilife\app\appfront\modules\Customer\block\address\Edit',
                ],
                'modules' => [
                    'customer' => [
                        'controllerMap' => [
                            'account' => 'fecbbco\app\appfront\modules\Customer\controllers\AccountController',    
                            'editaccount' => 'fecbbco\app\appfront\modules\Customer\controllers\EditaccountController', 
                            'address' => 'fecbbco\app\appfront\modules\Customer\controllers\AddressController', 
                        ],
                    ],
                    'checkout' => [
                        'controllerMap' => [
                            'onepage' => 'fecbbco\app\appfront\modules\Checkout\controllers\OnepageController',    
                        ],
                    ],
                ],
                'services' =>[
                    'page' => [
                        'childService' => [
                            'theme' => [
                                // 指定view文件的绝对路径，指定后，将不走多模板路径
                                'viewFileConfig' => [
                                ],
                            ],
                        ],
                    ],
                ],
            
            ],
        ],
        // html5入口
        'apphtml5' =>[
            // appfront入口的开关，如果false，则会失效
            'enable' => true,
            'config' => [
                // yii class rewrite map
                'yiiClassMap' => [],
                // 重写model和block
                'fecRewriteMap' => [],
                'modules' => [
                    'customer' => [
                        'controllerMap' => [
                            'account' => 'fecbbco\app\apphtml5\modules\Customer\controllers\AccountController',    
                            'editaccount' => 'fecbbco\app\apphtml5\modules\Customer\controllers\EditaccountController', 
                            'address' => 'fecbbco\app\apphtml5\modules\Customer\controllers\AddressController', 
                        ],
                    ],
                    'checkout' => [
                        'controllerMap' => [
                            'onepage' => 'fecbbco\app\apphtml5\modules\Checkout\controllers\OnepageController',    
                        ],
                    ],
                ],
                'services' =>[
                    'page' => [
                        'childService' => [
                            'theme' => [
                                // 指定view文件的绝对路径，指定后，将不走多模板路径
                                'viewFileConfig' => [
                                ],
                            ],
                        ],
                    ],
                ],
            
            ],
        ],
        // appserver入口（vue 微信小程序等api）
        'appserver' =>[],
        // appapi入口，和第三方交互的api
        'appapi' =>[],
        // 后台部分
        'appadmin' =>[],
        // console，命令行脚本端
        'console' =>[],
    ],
    
    
];

