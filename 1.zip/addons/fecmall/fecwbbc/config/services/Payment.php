<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    'payment' => [
        'class' => 'fecwbbc\services\Payment',
        'childService' => [
            'paypal' => [
                'class'    => 'fecwbbc\services\payment\Paypal',
            ],
            'alipay' => [
                'class'         => 'fecwbbc\services\payment\Alipay',
            ],
            'wxpay' => [ //注意参数要与WxPay.Config中的一致
        		'class'         => 'fecwbbc\services\payment\Wxpay', 
            ],
            'wxpayH5' => [ //注意参数要与WxPay.Config中的一致
        		'class'         => 'fecwbbc\services\payment\WxpayH5', 
            ],
            'wxpayJsApi' => [ //注意参数要与WxPay.Config中的一致
        		'class'         => 'fecwbbc\services\payment\WxpayJsApi', 
            ],
            'wxpayMicro' => [ //注意参数要与WxPay.Config中的一致
        		'class'         => 'fecwbbc\services\payment\WxpayMicro', 
            ],
        ],
    ],
];
