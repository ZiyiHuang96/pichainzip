<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    'order' => [
        'class' => 'fecwbbc\services\Order',
        'childService' => [
            'item' => [
                'class' => 'fecwbbc\services\order\Item',
            ],
            'info' => [
                'class' => 'fecwbbc\services\order\Info',
            ],
            'process' => [
                'class' => 'fecwbbc\services\order\Process',
            ],
            'afterSale' => [
                'class' => 'fecwbbc\services\order\AfterSale',
            ],
            'processLog' => [
                'class' => 'fecwbbc\services\order\ProcessLog',
            ],
        ],
    ],
];