<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    'cart' => [
        'class' => 'fecwbbc\services\Cart',
        // 子服务
        'childService' => [
            'info' => [
                'class' => 'fecwbbc\services\cart\Info',
            ],
            'quote' => [
                'class' => 'fecwbbc\services\cart\Quote',
            ],
            'quoteItem' => [
                'class' => 'fecwbbc\services\cart\QuoteItem',
            ],
        ],
    ],
];
