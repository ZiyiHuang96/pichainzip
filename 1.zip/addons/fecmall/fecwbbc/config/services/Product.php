<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    'product' => [
        'class' => 'fecwbbc\services\Product',
        'storagePath' => 'fecwbbc\\services\\product',
        'productSpuShowOnlyOneSku' => false,
        'childService' => [
            'review' => [
                'class' => 'fecwbbc\services\product\Review',
            ],
            'favorite' => [
                'class' => 'fecwbbc\services\product\Favorite',
            ],
            'stock' => [
                'class' => 'fecwbbc\services\product\Stock',
            ],
        ],
    ],
];
