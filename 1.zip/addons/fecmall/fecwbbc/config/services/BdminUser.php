<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    'bdminUser' => [
        'class' => 'fecwbbc\services\BdminUser',
        'childService' => [
            'bdminUser' => [
                'class' => 'fecwbbc\services\bdminUser\BdminUser',
            ],
            'userLogin' => [
                'class' => 'fecwbbc\services\bdminUser\UserLogin',
            ],
            'shipping' => [
                'class' => 'fecwbbc\services\bdminUser\Shipping',
            ],
            'shippingItem' => [
                'class' => 'fecwbbc\services\bdminUser\ShippingItem',
            ],
        ],
    ],
];
