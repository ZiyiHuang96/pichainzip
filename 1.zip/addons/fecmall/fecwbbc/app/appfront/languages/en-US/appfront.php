<?php 
return [
    'payment_pending' => 'Payment failed',
    'payment_confirmed' => 'Payment Confirmed',
    'payment_canceled' => 'Payment Canceled',
    'processing' => 'Processing',
    'dispatched' => 'Dispatched',
    'completed' => 'Completed',
    'canceled' => 'Canceled',
    'after_sale_waiting_return' => 'Wainting Service Audit ',
    'after_sale_return_accept' => 'Audit Accept',
    'after_sale_return_refuse' => 'Audit Refuse',
    'after_sale_return_cancel' => 'Canceled',
    'after_sale_return_dispatch' => 'Return Goods Dispatch',
    'after_sale_return_received' => 'Return Goods Received',
    'after_sale_return_refund' => 'Return Refund',
    
    'operate_waiting_canceled' => 'Order Cancel Waiting audit',
    'operate_canceled' => 'Order Canceled',
    'payment_processing' => 'Payment Processing',
    'payment_suspected_fraud' => 'Payment Suspected Fraud',
    'holded' => 'Holded',
    'received' => 'Received',
    'refunded' => 'Refunded',
    'order_audit_fail' => 'Order Audit Fail',
    
];