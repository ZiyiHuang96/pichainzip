<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace fecwbbc\app\appfront\modules\Customer\controllers;

use fecshop\app\appfront\modules\AppfrontController;
use Yii;

class AddressController extends \fecshop\app\appfront\modules\Customer\controllers\AddressController
{
    public $enableCsrfValidation = true;
    public $blockNamespace = 'fecwbbc\app\appfront\modules\Customer\block';

    public function init()
    {
        parent::init();
        if (Yii::$app->user->isGuest) {
            return Yii::$service->url->redirectByUrlKey('customer/account/login');
        }
        Yii::$service->page->theme->layoutFile = 'customer_address.php';
    }
    
    public function actionIndex()
    {
        if (Yii::$app->user->isGuest) {
            return Yii::$service->url->redirectByUrlKey('customer/account/login');
        }
        $defaultAddressId =  Yii::$app->request->get('defaultaddressid');
        if ($defaultAddressId) {
            // 更改default address id
            $customer_id = Yii::$app->user->identity->id;
            Yii::$service->customer->address->setDefault($customer_id, $defaultAddressId);
        }
        $data = $this->getBlock()->getLastData();
        if (!is_array($data) || empty($data)) {
            return Yii::$service->url->redirectByUrlKey('customer/address/edit');
        }
        return $this->render($this->action->id, $data);
    }

}

