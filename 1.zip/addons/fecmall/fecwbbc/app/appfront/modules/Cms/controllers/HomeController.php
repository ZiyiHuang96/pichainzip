<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecmall.com/license/
 */
namespace fecwbbc\app\appfront\modules\Cms\controllers;

use fecshop\app\appfront\modules\AppfrontController;
use Yii;
/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class HomeController extends \fecshop\app\appfront\modules\Cms\controllers\HomeController
{
    
    public $blockNamespace = 'fecwbbc\app\appfront\modules\Cms\block';
    
    public function init()
    {
        //echo 1222;exit;
        parent::init();
    }

    
}
