<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace fecwbbc\app\appfront\modules\Catalog\controllers;

use fecshop\app\appfront\modules\AppfrontController;
use Yii;

/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class QuickviewController extends AppfrontController
{
    
    // ajax 得到产品加入购物车的价格。
    public function actionIndex()
    {
        $product_id = Yii::$app->request->get('product_id');
        
            
        $rViewC = [
            'class' => '\fecwbbc\app\appfront\modules\Catalog\block\quickview\Index',
            'view'    => 'catalog/quickview/index.php',
            'product_id' => $product_id ,
        ];
        
        //echo Yii::$service->page->widget->renderContent('catalog_product_quick_view', $rViewC, $this);exit;
        
        echo json_encode([
            'status' => 200,
            'quick_view_content' =>Yii::$service->page->widget->renderContent('catalog_product_quick_view', $rViewC, $this),
        ]);
        
        exit;
    }
    
    
    
}
