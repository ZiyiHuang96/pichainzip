<?php
/**
 * FecMall file.
 * doc:https://packagist.org/packages/hightman/xunsearch.
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    // yii class rewrite map
    'yiiClassMap' => [
        // 'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',
    ],
    // 重写model和block
    'fecRewriteMap' => [
        '\fecshop\app\appfront\modules\Catalog\block\category\Index'  => '\fecwbbc\app\appfront\modules\Catalog\block\category\Index',
        '\fecshop\app\appfront\modules\Payment\block\paypal\standard\Start'  => '\fecwbbc\app\appfront\modules\Payment\block\paypal\standard\Start',
        '\fecshop\app\appfront\modules\Payment\block\success\Index'  => '\fecwbbc\app\appfront\modules\Payment\block\success\Index',
        '\fecshop\app\appfront\modules\Catalog\block\product\Index'  => '\fecwbbc\app\appfront\modules\Catalog\block\product\Index',
        '\fecshop\app\appfront\modules\Catalog\block\category\Price'  => '\fecwbbc\app\appfront\modules\Catalog\block\category\Price' ,
                    
        // '\fecshop\app\appfront\modules\Customer\block\address\Edit'  => '\fectb\app\appfront\modules\Customer\block\address\Edit',
    ],
    
    'components' => [
        // yii2 语言组件配置，关于Yii2国际化，可以参看：http://www.yiichina.com/doc/guide/2.0/tutorial-i18n
        'i18n' => [
            'translations' => [
                'appfront' => [
                    'basePaths' => [
                        '@fecwbbc/app/appfront/languages',
                    ],
                ],
            ],
        ],
    ],
    'modules' => [
        'payment' => [
            'controllerMap' => [
                'checkmoney' => 'fecwbbc\app\appfront\modules\Payment\controllers\CheckmoneyController',       
           ],
        ],
        'customer' => [
            'controllerMap' => [
                'account' => 'fecwbbc\app\appfront\modules\Customer\controllers\AccountController',       
                'editaccount' => 'fecwbbc\app\appfront\modules\Customer\controllers\EditaccountController',   
                'editpassword' => 'fecwbbc\app\appfront\modules\Customer\controllers\EditpasswordController', 
                'productfavorite' => 'fecwbbc\app\appfront\modules\Customer\controllers\ProductfavoriteController',       
                'productreview' => 'fecwbbc\app\appfront\modules\Customer\controllers\ProductreviewController',                   
                'coupon' => 'fecwbbc\app\appfront\modules\Customer\controllers\CouponController',      
                'address' => 'fecwbbc\app\appfront\modules\Customer\controllers\AddressController',      
                'order' => 'fecwbbc\app\appfront\modules\Customer\controllers\OrderController',    
               // 'wx' => 'fecwbbc\app\appfront\modules\Customer\controllers\WxController',                       
            ], 
            'params'=> [   
                'leftMenu'  => [ 
                    'My Coupon'             => 'customer/coupon',
                ],
            ],
        ],
        
        
        'catalog' => [
            'controllerMap' => [
                'reviewproduct' => 'fecwbbc\app\appfront\modules\Catalog\controllers\ReviewproductController',  
                'favoriteproduct' => 'fecwbbc\app\appfront\modules\Catalog\controllers\FavoriteproductController', 
                'shop' => 'fecwbbc\app\appfront\modules\Catalog\controllers\ShopController',  
                'quickview' => 'fecwbbc\app\appfront\modules\Catalog\controllers\QuickviewController',  
            ],
        ],
        'cms' => [
            'controllerMap' => [
                'home' => 'fecwbbc\app\appfront\modules\Cms\controllers\HomeController',  
            ],
        ],
        'catalogsearch' => [
            'controllerMap' => [
                'index' => 'fecwbbc\app\appfront\modules\Catalogsearch\controllers\IndexController',  
            ],
        ],
        'checkout' => [
            'controllerMap' => [
                'cartinfo' => 'fecwbbc\app\appfront\modules\Checkout\controllers\CartInfoController',          
                'cart' => 'fecwbbc\app\appfront\modules\Checkout\controllers\CartController', 
                'onepage' => 'fecwbbc\app\appfront\modules\Checkout\controllers\OnepageController',    
            ],
        ],
        'coupon' => [
            'class' => '\fecwbbc\app\appfront\modules\Coupon\Module',
        ],
    ],
    'services' => [
        'page' => [
            'childService' => [
                'widget' => [
                    'widgetConfig' => [
                        'base' => [
                            'header_mini' => [
                                'class' => 'fecshop\app\appfront\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => 'widgets/header_mini.php',
                                'cache' => [
                                    'timeout'    => 4500,
                                ],
                            ],
                            'header_shop' => [
                                'class' => 'fecshop\app\appfront\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => 'widgets/header_shop.php',
                                'cache' => [
                                    'timeout'    => 4500,
                                ],
                            ],
                        ],
                        'product' => [
                            'quick_view_options' => [
                                'view'	=> 'catalog/quickview/options.php'
                            ],
                            'quick_view' => [
                                'view'	=> 'catalog/quickview/view.php'
                            ],
                            'quick_view_image' => [
                                'view'	=> 'catalog/quickview/image.php'
                            ],
                            'coupon' => [
                                'view'  => 'catalog/product/index/coupon.php',
                            ],
                            'cart' => [
                                'view'  => 'catalog/product/index/cart.php',
                            ],
                            'price' => [
                                'class' 		=> 'fecwbbc\app\appfront\modules\Catalog\block\category\Price',
                                'view'	    => 'catalog/product/index/price.php'
                            ],
                            'image_detail' => [
                                'view'  => 'catalog/product/index/image_detail.php',
                            ],
                            'description' => [
                                'view'  => 'catalog/product/index/description.php',
                            ],
                        ],
                        
                        'cart' => [
                            'quick_view' => [
                                'view'	=> 'catalog/quickview/view_cart.php'
                            ],
                        ],
                        'checkout' => [
                            'onepage_address' => [
                                'view'	=> 'checkout/onepage/address.php'
                            ],
                            'onepage_addressedit' => [
                                'view'	=> 'checkout/onepage/addressedit.php'
                            ],
                        ],
                        
                        'order' => [
                            'coupon' => [
                                'view'  => 'checkout/onepage/index/coupon.php',
                            ],
                        ],
                        
                        'category' => [
                           // 'review_star' => [
                            //    'view'    => 'catalog/product/index/review_star.php'
                            //],
                            'toolbar_page' => [
                                'view'          => 'catalog/category/index/toolbar_page.php',
                            ],
                            'product_list' => [
                                'view'          => 'catalog/category/index/product_list.php',
                            ],
                        ],
                    ],
                ],
                'menu' => [
                    'behindCustomMenu' => [
                        [
                            'name'        => 'Fetch Coupon',            // 菜单名字
                            'urlPath'     => '/coupon/fetch/lists',    
                        ],
                        //[
                        //    'name'        => 'Newcomer Gift',            // 菜单名字
                        //    'urlPath'     => '/coupon/customer/registergift',    
                        //],
                    ],
                ],
            ],
        ],
    ],
];