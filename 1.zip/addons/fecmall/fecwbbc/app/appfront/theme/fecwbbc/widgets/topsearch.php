<form class="search_form_db search_form_db-js" id="search_form" method="get" action="<?= Yii::$service->url->getUrl('catalogsearch/index');   ?>">
    <div>
        <input type="text" placeholder="<?= Yii::$service->page->translate->__('Products Search'); ?>" value="<?=  \Yii::$service->helper->htmlEncode(Yii::$app->request->get('q'));  ?>" class="header-search__keyword-input cursor-pointer header-search-keyword-input-js" name="q" id="keywords" autocomplete="off" >
        <span class="position-absolute header-search__search-icon-new text-white btn btn-secondary header-search-icon-submit-js" >
            <i class="nc-icon nc-icon-search-24"></i>
        </span>
    </div>
    <div class="search-result-list search-result-list-container-js" style="display: none;"> 
        <div class="ajax-search-list">  
            <div class="pt-lg-20 header-search-hot-list-container-js"> 
                <div class="px-lg-20">
                    <i class="nc-icon nc-icon-hot-sale text-grey-light-1"></i>
                    <span class="font-bold font-normal mx-lg-6">
                        <?= Yii::$service->page->translate->__('Hot Searches'); ?>
                    </span>
                </div> 
                <ul class="flex justify-content-start flex-wrap px-lg-20 mx-lg-n6 pt-lg-12 text-grey-dark-1 mb-lg-30 header-search-hot-list-js">
                    <?php  
                        $hot_searchs = Yii::$app->store->get('fecbbc_info', 'hot_searchs'); 
                        $hot_search_arr = [];
                        if ($hot_searchs) {
                            $hot_search_arr = explode(',', $hot_searchs);
                        }
                        $hotIco = 2;
                        $ii=0;
                        //var_dump($hot_searchs);
                        if (is_array($hot_search_arr) && !empty($hot_search_arr)):
                            foreach ($hot_search_arr as $hot_search):
                                $ii++;
                    ?>
                        <li class="ajax-search__hot-list-item header-search-hot-list-item-link-js" title="<?=$hot_search ?>"  rel="<?= Yii::$service->url->getUrl('catalogsearch/index', ['q' => $hot_search]) ?>">
                            <span class="header-search-hot-list-item-text header-search-hot-list-item-text-js header-search-list-item-text-js">
                                <?php if ($ii <= 2): ?>
                                <span class="ajax-search__hot-list-icon-box">
                                    <img class="ajax-search__hot-list-icon" src="<?= Yii::$service->image->getImgUrl('addons/fecro/20200422040850_774.png') ?>" alt="" />
                                </span>
                                <?php endif; ?>
                                <?= $hot_search ?>
                            </span>
                        </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul> 
            </div> 
            <div class="header-search-complement-container-js" style="display: block;"></div> 
        </div>
    </div>
</form>

<script>	
<?php $this->beginBlock('top_search') ?>
$(document).ready(function(){
    $(".header-search__keyword-input").focus(function (e){
        $(".search-result-list").show();
        e.stopPropagation();
    });
    $(".header-search__keyword-input").click(function (e){
        e.stopPropagation();
    });
    //$(".header-search__keyword-input").blur(function (){
    //    $(".search-result-list").hide();
    //});
    $(document).on('click',':not(#search_form)',function(e){
        $(".search-result-list").hide();
        return;
    });
    
    $(".header-search__search-icon-new").click(function(e){
        $("#search_form").submit();
    });
    
    $(".ajax-search__hot-list-item").click(function(e){
        dataUrl = $(this).attr("rel");
        window.location.href = dataUrl;
        e.stopPropagation();
    });
});
<?php $this->endBlock(); ?> 
<?php $this->registerJs($this->blocks['top_search'],\yii\web\View::POS_END);//将编写的js代码注册到页面底部 ?>

</script> 












