<div class="flex justify-content-between align-items-center">
    <?php if(is_array($categoryArr) && !empty($categoryArr)): ?>
    <ul class="flex lg-21 justify-content-start header-nav__list header-nav-list-js">
        <?php foreach($categoryArr as $category1): ?>
            <li class="flex text-capitalize justify-content-center header-nav__item header-nav-item-js ">
                <a class="text-black header-nav-link-js" href="<?= $category1['url'] ?>" >
                    <span class="header-nav__link-underline d-inline-block font-normal">
                        <?= $category1['name'] ?>               
                    </span>
                </a>
                <?php $childMenu1 = isset($category1['childMenu']) ? $category1['childMenu'] : null;   ?>
                <?php $ik=0; ?>
                <?php if(is_array($childMenu1) && !empty($childMenu1)): ?>
                    <div class="header-nav__collapse border-top border-bottom pb-lg-30 bg-white header-nav-collapse-js">
                        <div class="flex justify-content-center no-wrap mt-lg-25 container header-nav__collapse-inner">
                            <div class="flex justify-content-around header-nav__collapse-inner-content">
                                <div class="header-nav__container--menu mx-lg-n10 flex justify-content-end">
                                    <ul class="header-nav__menu-list px-lg-10 font-normal">
                                        <?php foreach($childMenu1 as $category2): ?>
                                            <?php $childMenu2 = isset($category2['childMenu']) ? $category2['childMenu'] : null;   ?>
                                            <?php if(is_array($childMenu2) && !empty($childMenu2)): ?>
                                                <?php $ik++; ?>
                                                <li class="header-nav__menu-item ">
                                                    <span class="header-nav__menu-no-link  font-bold menu-link-title">
                                                        <?= $category2['name'] ?>
                                                    </span>
                                                </li>
                                                <?php foreach($childMenu2 as $category3): ?>
                                                    <?php $ik++; ?>
                                                    <li class="header-nav__menu-item ">
                                                        <a class="header-nav__menu-link " href="<?= $category3['url'] ?>" >
                                                            <?= $category3['name'] ?>
                                                        </a>
                                                    </li>
                                                    <?php if ($ik%10 == 0): ?>
                                                        </ul>
                                                        <ul class="header-nav__menu-list px-lg-10 font-normal">
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <?php $ik++; ?>
                                                <li class="header-nav__menu-item title-margin ">
                                                    <a class="header-nav__menu-link  font-bold menu-link-title" href="<?= $category2['url'] ?>" >
                                                        <?= $category2['name'] ?>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if ($ik%10 == 0): ?>
                                                </ul>
                                                <ul class="header-nav__menu-list px-lg-10 font-normal">
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?= isset($category1['menu_custom']) ? $category1['menu_custom'] : '';  ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
    <div class="lg-3 flex justify-content-end font-small header-nav-free-shipping-tips-js"></div>
</div>

<script>
    <?php $this->beginBlock('top_menu') ?>
    $(document).ready(function(){
        $(".header-nav__item").hover(function(){
            $(this).addClass("active");
        },function(){
            $(this).removeClass("active");
        });
    });
    <?php $this->endBlock(); ?>
    <?php $this->registerJs($this->blocks['top_menu'],\yii\web\View::POS_END);//将编写的js代码注册到页面底部 ?>
</script>   

