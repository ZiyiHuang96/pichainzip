<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
?>
<?php $items = Yii::$service->page->breadcrumbs->getItems();    ?>
<?php if(is_array($items) && !empty($items)):    ?>
<div class="mt-lg-20 mb-lg-15"> 
    <ul class="breadcrumb breadcrumb-js"> 
	<?php  $count = count($items); $i=0;  ?>
	<?php  foreach($items as $item):  $i++; ?>
		<?php  ($i == $count) ? ($str = '') : ($str = '>')  ?>
		<?php $name = isset($item['name']) ? $item['name'] : ''; ?>
		<?php $name = Yii::$service->page->translate->__($name); ?>
		<?php $url  = isset($item['url']) ? $item['url'] : ''; ?>
		<?php  if($name): ?>
			<?php  if($url): ?>
                <li class="breadcrumb-item breadcrumb-item-js ">
                    <a class="breadcrumb-link breadcrumb-link-js breadcrumb-ga-js" href="<?= $url ?>">
                        <?= $name ?>
                    </a>
                </li>
			<?php  else:   ?>
                <li class="breadcrumb-item breadcrumb-item-js active">
                    <h1 class="d-inline-block">
                        <a class="breadcrumb-link breadcrumb-link-js breadcrumb-ga-js d-inline-block btn-cursor breadcrumb-last-link" href="javascript:;">
                            <?= $name ?>
                        </a>
                    </h1>
                </li> 
			<?php  endif;   ?>
		<?php  endif;   ?>
	<?php  endforeach;   ?>
    </ul>
</div>
<?php endif; ?>

    