<div class="common-footer__wrapper common-footer-js">
    <?=  Yii::$service->cms->staticblock->getStoreContentByIdentify('pc-home-footer','appfront') ?>
</div>
