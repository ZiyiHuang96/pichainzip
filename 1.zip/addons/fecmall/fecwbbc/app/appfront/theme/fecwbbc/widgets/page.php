<div class="flex justify-content-center mb-lg-50 mt-lg-30 cate-pagination-container-js">
    <ul class="pagination">
	<?php  if($prevPage):  ?>
        <li class="page-item page-item-first">
            <a class="page-link" href="<?= $prevPage['url']['url'] ?>">
                <i class="nc-icon nc-icon-left-16"></i>
            </a>
        </li>
	<?php else:  ?>
        <li class="page-item page-item-first disabled">
            <a class="page-link" href="javascript:void()">
                <i class="nc-icon nc-icon-left-16"></i>
            </a>
        </li>
	<?php endif;  ?>	
	<?php if($firstSpaceShow):  ?>
        <li class="page-item">
            <a class="page-link" href="<?= $firstSpaceShow['url']['url'] ?>">
                <?= $firstSpaceShow[$pageParam] ?>
            </a>
        </li>
	<?php endif;  ?>
    <li class="page-item disabled">
        <?= $hiddenFrontStr ?>
    </li>	
			
	<?php  if(!empty($frontPage )): ?>
		<?php foreach($frontPage as $page): ?>
            <li class="page-item">
                <a class="page-link" href="<?= $page['url']['url'] ?>">
                    <?= $page[$pageParam] ?>
                </a>
            </li>
		<?php endforeach;  ?>	
	<?php endif;  ?>	
	
	<?php if($currentPage): ?>
        <li class="page-item active">
            <a class="page-link" href="javacript:void()">
                <?= $currentPage[$pageParam] ?>
            </a>
        </li>
	<?php endif;  ?>	
	
	<?php if(!empty($behindPage )): ?>
		<?php foreach($behindPage as $page): ?>
            <li class="page-item">
                <a class="page-link" href="<?= $page['url']['url'] ?>">
                    <?= $page[$pageParam] ?>
                </a>
            </li>
		<?php endforeach;  ?>	
	<?php endif;  ?>		
	<li class="page-item disabled">
        <?= $hiddenBehindStr ?>			
    </li>		
	
	<?php if($lastSpaceShow): ?>
        <li class="page-item">
            <a class="page-link" href="<?= $lastSpaceShow['url']['url'] ?>">
                <?= $lastSpaceShow[$pageParam] ?>
            </a>
        </li>
	<?php endif;  ?>	
	<?php if($nextPage):  ?>
        <li class="page-item page-item-next">
            <a class="page-link" href="<?= $nextPage['url']['url'] ?>">
                <i class="nc-icon nc-icon-arrows-16"></i>
            </a>
        </li>
	<?php else:  ?>
        <li class="page-item page-item-next disabled">
            <a class="page-link" href="javacript:void()">
                <i class="nc-icon nc-icon-arrows-16"></i>
            </a>
        </li>
	<?php endif;  ?>	
    </ul>
</div> 
