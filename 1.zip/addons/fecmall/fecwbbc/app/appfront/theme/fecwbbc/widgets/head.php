<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
?>

<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?= \Yii::$app->view->title; ?></title>
<link rel="shortcut icon" href="<?=  Yii::$service->url->getUrl('favicon.ico'); ?>">
<link rel="apple-touch-icon" href="<?=  Yii::$service->url->getUrl('apple-touch-icon.png'); ?>">
<meta name="robots" content="INDEX,FOLLOW" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script>
  window._initHtmlREM = function(){
    var rootHtml = document.documentElement;
    var width = rootHtml.clientWidth;
    if (width < 1700 && width >= 1024) {
      rootHtml.style.fontSize = (width * 100 / 1700) + 'px';
    } else if (width < 1024){
      rootHtml.style.fontSize = '61.7px';
    } else if (width >= 1700) {
      rootHtml.style.fontSize = '100px';
    }
  }
  window._initHtmlREM();
</script>
<?php $parentThis->head() ?>
<script>
(function(doc, win) {
    var html = doc.getElementsByTagName("html")[0],
    // orientationchange->手机屏幕转屏事件
    // resize->页面大小改变事件(一边pc端有用)
    reEvt = "orientationchange" in win ? "orientationchange" : "resize",
    reFontSize = function() {
        var clientW = doc.body.clientWidth || doc.documentElement.clientWidth ;
        if(!clientW) {
            return;
        }
        html.style.fontSize =  (clientW /19.03) + "px ";
    }
    win.addEventListener(reEvt, reFontSize);
    // DOMContentLoaded->dom加载完就执行,onload要dom/css/js都加载完才执行
    doc.addEventListener("DOMContentLoaded", reFontSize);
})(document, window);
</script>