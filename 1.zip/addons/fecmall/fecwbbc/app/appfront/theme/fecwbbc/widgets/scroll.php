<div class="fix-sidebar__list">
    <div class="position-relative">
        <a href="" class="fix-sidebar__activity-entry fix-sidebar-header-img-js hidden not-product-pic"></a>
    </div>
    <ul>
    
    <li class="fix-sidebar__item">
      <a href="<?= Yii::$service->url->getUrl('customer/contacts') ?>" class="fix-sidebar__link fix-sidebar__link--service fix-sidebar-link-service-js">
        <i class="nc-icon nc-icon-online-help-241 fix-sidebar-option-icon"></i>
      </a>
    </li>
    <li class="fix-sidebar__item fix-sidebar-top-js">
      <a class="fix-sidebar__link fix-sidebar__link--top go_top"  id="goTop"  href="#gotop" >
        <i class="nc-icon nc-icon-angle-up fix-sidebar-option-icon"></i>
      </a>
    </li>
  </ul>
</div>