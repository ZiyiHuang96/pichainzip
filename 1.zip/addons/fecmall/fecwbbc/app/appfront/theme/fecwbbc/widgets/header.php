<div class="common-header-js">
    <input type="hidden" class="currentBaseUrl" value="<?= $currentBaseUrl ?>" />
    <input type="hidden" class="current_lang" value="<?= $currentStore ?>" />
    <div class="header__wrapper header-menu-wrapper-js" style="height: 127px;">
        <div class="header__container header-top-container-js myos_pages_head_fix  ">
            <div class="container">
                <div class="flex align-items-center justify-content-between py-lg-24 bg-white font-small">
                    <div class="lg-8 flex">
                        <a class="d-block" href="<?= Yii::$service->url->homeUrl() ?>">
                            <img src="<?= $logoImgUrl ?>" alt="" style="height:39px;">
                        </a>
                    </div>
                    <div class="lg-8 flex justify-content-center header-search-js">
                        <div class="position-relative header-search__input-container">
                            <?= Yii::$service->page->widget->render('base/topsearch',$this); ?>
                        </div>
                    </div>
                    
                    <div class="lg-8">
                        <div class="flex justify-content-end align-items-center mx-lg-n22">
                            <div class="mx-lg-20 position-relative header-right-container header-right-container-js header-right-user-container-js">
                                <div class="cursor-pointer header-right-user-icon">
                                    <a class="d-block text-secondary text-hover-none header-user-link-js" href="<?= Yii::$service->url->getUrl('customer/account') ?>" >
                                        <i class="nc-icon nc-icon-sign-in-24 font-size-24"></i>
                                    </a>
                                </div>
                                
                                <div class="position-absolute header-right-collapse-container header-right-collapse-container-js header-user-collapse-container active">
                                    <div class="header-right-user__register-guide pa-lg-24" style="display:block">
                                        <p class="font-bold mb-lg-5">
                                            <?= Yii::$service->page->translate->__('Welcome to {fecmall}', ['fecmall' =>  Yii::$service->helper->getBaseWebsiteName() ]); ?>
                                        </p>
                                        <a href="<?= Yii::$service->url->getUrl('customer/account/login')  ?>" class="btn btn-secondary btn-block register-guide-btn" >
                                            <?= Yii::$service->page->translate->__('Sign in / Register'); ?>
                                        </a>
                                    </div>
                                    
                                    <div class="header-right-user__user-info" style="display: none">
                                        <ul class="py-lg-6">
                                            <li>
                                                <a href="<?= Yii::$service->url->getUrl('customer/order') ?>" class="d-block user-info__link-list-item">
                                                    <div class="flex no-wrap">
                                                        <i class="nc-icon nc-icon-all"></i>
                                                        <span class="lg-20 mx-lg-8 text-ellipsis">
                                                            <?= Yii::$service->page->translate->__('View Orders'); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= Yii::$service->url->getUrl('customer/productfavorite') ?>" class="d-block user-info__link-list-item" >
                                                    <div class="flex no-wrap">
                                                        <i class="nc-icon nc-icon-my-wishlist"></i>
                                                        <span class="lg-20 mx-lg-8 text-ellipsis">
                                                            <?= Yii::$service->page->translate->__('My Wishlist'); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            </li>
                                            
                                            <li>
                                                <a href="<?= Yii::$service->url->getUrl('customer/coupon') ?>" class="d-block user-info__link-list-item" >
                                                    <div class="flex no-wrap">
                                                        <i class="nc-icon nc-icon-my-coupons"></i>
                                                        <span class="lg-20 mx-lg-8 text-ellipsis">
                                                            <?= Yii::$service->page->translate->__('My Coupons'); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= Yii::$service->url->getUrl('customer/address') ?>" class="d-block user-info__link-list-item" >
                                                    <div class="flex no-wrap">
                                                        <i class="nc-icon nc-icon-address-book"></i>
                                                        <span class="lg-20 mx-lg-8 text-ellipsis">
                                                            <?= Yii::$service->page->translate->__('Address Book'); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= Yii::$service->url->getUrl('customer/account/logout') ?>" class="d-block user-info__link-list-item" >
                                                    <div class="flex no-wrap">
                                                        <i class="nc-icon nc-icon-sign-out-16"></i>
                                                        <span class="lg-20 mx-lg-8 text-ellipsis">
                                                            <?= Yii::$service->page->translate->__('Logout'); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="mx-lg-20 flex align-items-center">
                                <div class="cursor-pointer header-right-user-wishlist-icon">
                                    <a class="flex align-items-center text-secondary text-hover-none header-user-wishlist-link-js" href="<?= Yii::$service->url->getUrl('customer/productfavorite') ?>">
                                        <i class="nc-icon nc-icon-wishlist-24 font-size-24"></i>
                                        <span class="header-right-user-wishlist-num-js">0</span>
                                    </a>
                                </div>
                            </div>
                            <div class="active mx-lg-20 position-relative flex align-items-center header-right-container header-right-container-js header-right-bag-container-js">
                                <a href="<?= Yii::$service->url->getUrl('checkout/cart') ?>" class="flex align-items-center text-secondary text-hover-none">
                                    <div class="cursor-pointer header-right-user-bag-icon">
                                        <i class="nc-icon nc-icon-bag-24 font-size-24"></i>
                                    </div>
                                    <div class="header-right-user-bag-num header-right-user-bag-num-js">0</div>
                                </a>
                                
                                <div style="display:block;" class=" position-absolute header-right-collapse-container header-right-collapse-container-js header-bag-collapse-container header-bag-collapse-container-js header-bag--normal">
                                    <div class="header-right__header-bag header-bag-collapse-inner-js">
                                        <div class="cartItems" style="display:none;">
                                            <div class="header-bag__list-container header-bag-list-scrollbar-js mCustomScrollbar _mCS_1" style="overflow: hidden;">
                                                <div class="mCustomScrollBox mCS-light" id="mCSB_1" style="position: relative; height: 100%;     overflow: overlay; max-width: 100%; max-height: 380px;">
                                                    <div class="mCSB_container mCS_no_scrollbar" style="position:relative; top:0;">
                                                        <ul class="header-bag-list-container-js">
                                                            
                                                        </ul>
                                                    </div>
                                                    
                                                </div>
                                            </div>    
                                            <div class="header-bag__subtotal-outer text-grey-dark-1 font-small">      
                                                    
                                                <div class="header-bag__subtotal font-normal">        
                                                    <?= Yii::$service->page->translate->__('Subtotal'); ?> : 
                                                    <span class="price text-primary font-bold font-size-24 header-bag-subtotal-price-js" >0</span>      
                                                </div>      
                                                <a href="<?= Yii::$service->url->getUrl('checkout/cart') ?>" class="btn btn-secondary btn-block text-capitalize header-bag__checkout-btn">
                                                    <?= Yii::$service->page->translate->__('View Bag/Checkout'); ?>
                                                </a>    
                                            </div>  
                                        </div>
                                        
                                        <div class="text-center pb-lg-25 cartEmpty" style="display:none;">
                                            <div class="flex align-items-center justify-content-center column text-center pt-lg-20">
                                                <div class="header-bag__empty-bag-bg"></div>
                                                <p class="font-bold">
                                                    <?= Yii::$service->page->translate->__('Your Shopping Bag is Empty.'); ?>
                                                </p>
                                             </div>      
                                        </div>
                                        
                                    </div>
                                </div>
                                
                            </div>
                            <div class="mx-lg-20 position-relative header-right-container header-right-container-js">
                                <div class="cursor-pointer header-right-online-help-icon">
                                    <a href="<?= Yii::$service->url->getUrl('customer/contacts') ?>" style="color:#333" >
                                        <i class="nc-icon nc-icon-online-help-241 font-size-24"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="mx-lg-20">
                                <div class="drop-menu">
                                    <div class="inputWrap">
                                        <div class="input langCurrency" style="cursor:pointer"><?= $currentStoreLang ?> / <?= $currency['code'] ?></div>
                                    </div>
                                    <!--
                                    <div style="width: 200px; left: -140px;  width: 240px;  background: #fff; padding: 20px; " class="lang position-absolute header-right-collapse-container header-right-collapse-container-js header-bag-collapse-container header-bag-collapse-container-js header-bag--normal">
                                        <div class="header-right__header-bag header-bag-collapse-inner-js">
                                            
                                        </div>
                                    </div>
                                    -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?= Yii::$service->page->widget->render('base/menu',$this); ?>
            </div>
        </div>
    </div>
    <div class="common-header-bg"></div>
</div>

<div class="langCurrency-backdrop modal-backdrop fade show" style="display:none!important;"></div>
<div class="langCurrency-fade modal fade user-select-modal show" style="display:none!important;" >
    <div class="modal-dialog-nc modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <i class="nc-icon nc-icon-close-two-16 text-grey"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="mb-lg-28 modal-language-select-outer-js">
                    <p class="font-bold mb-lg-8">
                        <?= Yii::$service->page->translate->__('Language'); ?>
                    </p>
                    <div class="modal-select-container modal-language-select-container modal-language-select-container-js">
                        <div class="select">
                            <div class="select-input-container select-input-container-js" >
                                <div class="select-text-box select-text-js text-ellipsis currentLang" rel="<?= $currentStore ?>">
                                    <?= $currentStoreLang ?>
                                </div>
                                <i class="nc-icon nc-icon-arrows-below- icon-arrows"></i>
                            </div>
                            <div class="select-menu select-menu-js"  style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 1px, 0px);">
                                <div class="border-bottom select-curent-item select-curent-item-js"><?= $currentStoreLang ?></div>
                                <ul class="select-item-container select-item-container-js mCustomScrollbar _mCS_2" style="overflow: hidden;">
                                    <div class="mCustomScrollBox mCS-light" id="mCSB_2" style="position: relative; height: 100%; overflow: hidden; max-width: 100%; max-height: 240px;">
                                        <div class="mCSB_container mCS_no_scrollbar" style="position: relative; top: 0px;">
                                            <?php foreach($stores as $store=> $langName):   ?>
                                                <li  class="select-item select-item-js"  rel="<?= $store ?>"><?= $langName ?> </li>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-lg-28 modal-language-select-outer-js">
                    <p class="font-bold mb-lg-8">
                        <?= Yii::$service->page->translate->__('Currency'); ?>
                    </p>
                    <div class="modal-select-container modal-language-select-container modal-language-select-container-js">
                        <div class="select">
                            <div class="select-input-container select-input-container-js" >
                                <div class="select-text-box select-text-js text-ellipsis currentCurrency" rel="<?= $currency['code'] ?>">
                                    <?= $currency['symbol'] ?> <?= $currency['code'] ?>
                                </div>
                                <i class="nc-icon nc-icon-arrows-below- icon-arrows"></i>
                            </div>
                            <div class="select-menu select-menu-js"  style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 1px, 0px);">
                                <div class="border-bottom select-curent-item select-curent-item-js">
                                    <?= $currency['symbol'] ?> <?= $currency['code'] ?>
                                </div>
                                <ul class="select-item-container select-item-container-js mCustomScrollbar _mCS_2" style="overflow: hidden;">
                                    <div class="mCustomScrollBox mCS-light" id="mCSB_2" style="position: relative; height: 100%; overflow: hidden; max-width: 100%; max-height: 240px;">
                                        <div class="mCSB_container mCS_no_scrollbar" style="position: relative; top: 0px;">
                                            <?php foreach($currencys as $c):    ?>
                                                <li class="select-item select-item-js" rel="<?= $c['code'] ?>">
                                                    <?= $c['symbol'] ?><?= $c['code'] ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn lang_currency btn-secondary btn-block modal-submit-btn modal-submit-btn-js">
                    <?= Yii::$service->page->translate->__('OK'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .header-right-user-container-js:hover .header-right-collapse-container{
        display:block;
    }
</style>
<script>
    <?php $this->beginBlock('top_lang') ?>
    function loadCartInfo()
    {
        var cartInfoUrl = currentBaseUrl+"/checkout/cartinfo/index";
        $.ajax({
            async: true,
            timeout: 6000,
            dataType: 'json',
            type: 'get',
            url: cartInfoUrl,
            success: function(data, textStatus){
                //$(".cart-loading").hide();
                var product_total = data.product_total;
                var cart_items = '';
                if (parseFloat(product_total) > 0) {
                    $(".cart-summary-info").show();
                    var c_symbol = data.symbol;
                    var products = data.products;
                    for (var x in products) {
                        product = products[x];
                        product_image = product['product_image'];
                        name = product['name'];
                        product_price = product['product_price'];
                        product_url = product['product_url'];
                        item_id = product['item_id'];
                        qty = product['qty'];
                        custom_option_info = product['custom_option_info'];
                        cart_items += '<li class="py-lg-16 px-lg-24 flex justify-content-center header-bag__list-item">';
                        //cart_items +=   '<div class="cart-float-single-item-image">';
                        cart_items +=       '<a class="d-block header-bag__list-item__img-container header-bag-list-link-js" href="'+ product_url +'" ><img class="lazyload lazy-loaded show header-bag-list-img-js" src="'+ product_image +'"></a>';
                        cart_items +=   ' <div class="header-bag__list-item__info">';
                        cart_items +=   ' <p class="text-ellipsis mb-lg-8 header-bag__list-item__title">';
                        cart_items +=       '<a class="text-grey text-hover-underline header-bag-list-link-js header-bag-list-name-js" href="'+ product_url +'">'+ name +'</a></p>';
                        cart_items +=   '<div class="flex justify-content-between mb-lg-24"><p class="header-bag-list-attr-value-js">' + custom_option_info + '</p>';
                        cart_items +=       '<p>X<span class="header-bag-list-qty-js">'+ qty +'</span></p></div>';
                        cart_items +=       '<div class="flex justify-content-between"><p class="font-bold font-middle price header-bag-list-price-js" >'+ c_symbol + product_price + '</p></div>';
                        cart_items +=   '</div>';
                        cart_items += '</li>'; 
                    }
                    $(".header-bag-list-container-js").html(cart_items);
                    $(".header-bag-subtotal-price-js").html(c_symbol + product_total);
                    $(".cartItems").show();
                    $(".cartEmpty").hide();
                    $(".header-bag-collapse-container-js").show();
                } else {
                    // cartItems cartEmpty
                    $(".cartEmpty").show();
                    $(".cartItems").hide();
                    $(".header-bag-collapse-container").show();
                }
            },
            error:function (XMLHttpRequest, textStatus, errorThrown){
                $(".cartEmpty").show();
            }
        }); 
    }
    
    $(document).ready(function(){
        $(".drop-menu .langCurrency").click(function(){
            $(".langCurrency-backdrop").show();
            $(".langCurrency-fade").show();
        });
        
        $(".langCurrency-fade").click(function(e){
            $(".langCurrency-backdrop").hide();
            $(".langCurrency-fade").hide();
        });
        
        $(".modal-dialog-centered").click(function(e){
            e.stopPropagation();
        });
        
        $(".langCurrency-fade .nc-icon-close-two-16").click(function(){
            $(".langCurrency-backdrop").hide();
            $(".langCurrency-fade").hide();
        });
        
        function getCaption(url,parameter) {
            var index = url.lastIndexOf(parameter);
            url = url.substring(0, index);
            return url;
        }

        $(".lang_currency").click(function(){
            changeStore = $(".modal-language-select-outer-js .currentLang").attr("rel");
            currentCurrency = $(".modal-language-select-outer-js .currentCurrency").attr("rel");
            
            ctUrl = "<?= Yii::$service->url->getUrl('cms/home/changecurrency') ?>";
            htmlobj=$.ajax({url: ctUrl+"?currency="+currentCurrency, async:false});
            
            location.reload() ;
            currentUrl = window.location.href;
            currentStore = $(".current_lang").val();
            redirectUrl = currentUrl.replace("://"+currentStore,"://"+changeStore);
            redirectUrl = getCaption(redirectUrl, "#");
            window.location.href=redirectUrl;
            //alert(redirectUrl);
        });
        
        $(".select-item-js").click(function(){
            langKey = $(this).attr("rel");
            langName = $(this).html();
            var s = $(this).parent().parent().parent().parent().parent();
            s.find(".select-text-box").attr("rel", langKey);
            s.find(".select-text-box").html(langName);
            s.removeClass("show");
            s.find(".select-menu.select-menu-js").removeClass("show");
        });
        
        $(".select-curent-item").click(function(){
            $(this).parent().parent().removeClass("show");
            $(this).parent().parent().find(".select-menu.select-menu-js").removeClass("show");
        });
        
        $(".select-input-container-js").click(function(){
            if ($(this).parent().hasClass("show")) {
                $(this).parent().removeClass("show");
                $(this).parent().find(".select-menu.select-menu-js").removeClass("show");
            } else {
                $(this).parent().addClass("show");
                $(this).parent().find(".select-menu.select-menu-js").addClass("show");
            }
        });
        
        // 顶部购物车
        $(".header-right-bag-container-js").hover(function(){
            $(this).addClass("active");
            $(this).find(".header-right-collapse-container").show();
            loadCartInfo();
        },function(){
            $(this).removeClass("active");
            $(this).find(".header-right-collapse-container").hide();
        });
        
        //  $(".header__container").addClass("header__container--fixed");
        // $(".header__container").addClass("show");
        
    });
    

    // 鼠标滑轮滑动，控制方向
    function scroll(fn) {
        var beforeScrollTop = document.body.scrollTop || document.documentElement.scrollTop,
        fn = fn || function() {};
        window.addEventListener("scroll", function() {
            var afterScrollTop = document.body.scrollTop || document.documentElement.scrollTop,
            delta = afterScrollTop - beforeScrollTop;
            if(delta == 0) return false;
            fn(delta > 0 ? "down" : "up");
            beforeScrollTop = afterScrollTop;
        }, false);
    }
    //调用滚动方向：到达底部并且向下滚动的时候，加载更多评论
    scroll(function(direction) {
        if(direction=="down"){
            $(".header__container").removeClass("header__container--fixed");
            $(".header__container").removeClass("show");
        } else {
            $(".header__container").addClass("header__container--fixed");
            $(".header__container").addClass("show");
        }              
    });     

    <?php $this->endBlock(); ?>
    <?php $this->registerJs($this->blocks['top_lang'],\yii\web\View::POS_END);//将编写的js代码注册到页面底部 ?>
</script>   