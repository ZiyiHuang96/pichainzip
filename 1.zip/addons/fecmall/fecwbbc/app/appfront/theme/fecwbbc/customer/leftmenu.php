<?php 
    $key = $parentThis['key'];
?>
<div class="side-nav bg-white pb-lg-50">
    <dl class="mx-lg-20 pt-lg-25 border-bottom mb-lg-20 side-nav-top">
        <dt class="font-middle">
            <h2>
                <a class="side-nav-link side-my-account nav-my-account-js" title="My Account" href="" >
                    <?= Yii::$service->page->translate->__('My Account'); ?>
                </a>
            </h2>
        </dt>
    </dl>
    <dl class="mb-lg-30">
        <dt class="font-bold px-lg-20 py-lg-5 font-normal">
            <?= Yii::$service->page->translate->__('My Orders'); ?>
        </dt>
        <dd>
            <a  href="<?= Yii::$service->url->getUrl('customer/order', ['order_status' => 'customer_order_all']) ?>"  class="side-nav-link nav-order-all-js px-lg-20 <?= $key == 'customer_order_all'   ? 'active' : '' ?> " title="ALL" >
                <i class="nc-icon nc-icon-unhover nc-icon-all"></i>
                <i class="nc-icon nc-icon-hover nc-icon-all-hover"></i>
                <?= Yii::$service->page->translate->__('ALL'); ?> 
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/order', ['order_status' => 'customer_order_unpaid']) ?>" class="side-nav-link nav-order-unpaid-js px-lg-20 <?= $key == 'customer_order_unpaid'   ? 'active' : '' ?> " title="Unpaid" >
                <i class="nc-icon nc-icon-unhover nc-icon-unpaid"></i>
                <i class="nc-icon nc-icon-hover nc-icon-unpaid-hover"></i>
                <?= Yii::$service->page->translate->__('Unpaid'); ?> 
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/order', ['order_status' => 'customer_order_processing']) ?>" class="side-nav-link nav-order-processing-js px-lg-20 <?= $key == 'customer_order_processing'   ? 'active' : '' ?> " title="Processing"  >
                <i class="nc-icon nc-icon-unhover nc-icon-processing"></i>
                <i class="nc-icon nc-icon-hover nc-icon-processing-hover"></i>
                <?= Yii::$service->page->translate->__('Processing'); ?> 
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/order', ['order_status' => 'customer_order_shipped']) ?>" class="side-nav-link nav-order-shipped-js px-lg-20 <?= $key == 'customer_order_shipped'   ? 'active' : '' ?> " title="Shipped"  >
                <i class="nc-icon nc-icon-unhover nc-icon-shipped"></i>
                <i class="nc-icon nc-icon-hover nc-icon-shipped-hover"></i>
                <?= Yii::$service->page->translate->__('Shipped'); ?> 
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/order', ['order_status' => 'customer_order_cancel']) ?>" class="side-nav-link nav-order-closed-js px-lg-20 <?= $key == 'customer_order_cancel'   ? 'active' : '' ?> " title="Closed" >
                <i class="nc-icon nc-icon-unhover nc-icon-closed"></i>
                <i class="nc-icon nc-icon-hover nc-icon-closed-hover"></i>
                <?= Yii::$service->page->translate->__('Closed'); ?> 
            </a>
        </dd>
    </dl>
    
    <dl class="mb-lg-30">
        <dt class="font-bold px-lg-20 py-lg-5 font-normal">
            <?= Yii::$service->page->translate->__('My Assets'); ?>
        </dt>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/coupon') ?>"  class="side-nav-link nav-my-coupons-js px-lg-20 <?= $key == 'customer_coupon'   ? 'active' : '' ?> " title="My Coupons" >
                <i class="nc-icon nc-icon-unhover nc-icon-my-coupons"></i>
                <i class="nc-icon nc-icon-hover nc-icon-my-coupons-hover"></i>
                <?= Yii::$service->page->translate->__('My Coupons'); ?>
            </a>
        </dd>
    </dl>
    
    <dl class="mb-lg-30">
        <dt class="font-bold px-lg-20 py-lg-5 font-normal">
            <?= Yii::$service->page->translate->__('Account Information'); ?>
        </dt>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/editaccount') ?>" class="side-nav-link nav-my-info-js px-lg-20 <?= $key == 'customer_editaccount'   ? 'active' : '' ?> " title="Personal Info"  >
                <i class="nc-icon nc-icon-unhover nc-icon-personal-info"></i>
                <i class="nc-icon nc-icon-hover nc-icon-personal-info-hover"></i>
                <?= Yii::$service->page->translate->__('Personal Info'); ?>
            </a>
        </dd>
        
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/address') ?>" class="side-nav-link nav-address-book-js px-lg-20 <?= $key == 'customer_address'   ? 'active' : '' ?>" title="Address Book"  >
                <i class="nc-icon nc-icon-unhover nc-icon-address-book"></i>
                <i class="nc-icon nc-icon-hover nc-icon-address-book-hover"></i>
                <?= Yii::$service->page->translate->__('Address Book'); ?>
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/productfavorite') ?>" class="side-nav-link nav-my-wishlist-js px-lg-20 <?= $key == 'customer_wishlist'   ? 'active' : '' ?>" title="My Wishlist"  >
                <i class="nc-icon nc-icon-unhover nc-icon-my-wishlist"></i>
                <i class="nc-icon nc-icon-hover nc-icon-my-wishlist-hover"></i>
                <?= Yii::$service->page->translate->__('My Wishlist'); ?>
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/productreview') ?>" class="side-nav-link nav-my-reviews-js px-lg-20 <?= $key == 'customer_review'   ? 'active' : '' ?>" title="My Reviews"  >
                <i class="nc-icon nc-icon-unhover nc-icon-my-reviews"></i>
                <i class="nc-icon nc-icon-hover nc-icon-my-reviews-hover"></i>
                <?= Yii::$service->page->translate->__('My Reviews'); ?>
            </a>
        </dd>
        <dd>
            <a href="<?= Yii::$service->url->getUrl('customer/editpassword') ?>" class="side-nav-link nav-password-js px-lg-20 <?= $key == 'customer_password'   ? 'active' : '' ?>" title="Change Password" >
                <i class="nc-icon nc-icon-unhover nc-icon-change-password"></i>
                <i class="nc-icon nc-icon-hover nc-icon-change-password-hover"></i>
                <?= Yii::$service->page->translate->__('Change Password'); ?>
            </a>
        </dd>
    </dl>
</div>
        