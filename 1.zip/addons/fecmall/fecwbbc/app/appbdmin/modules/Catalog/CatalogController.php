<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */

namespace fecwbbc\app\appbdmin\modules\Catalog;

/*
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
use fecadmin\FecadminbaseController;
use Yii;
use fecwbbc\app\appbdmin\modules\AppbdminController;

class CatalogController extends AppbdminController
{
    //public function getViewPath()
    //{
    //    return Yii::getAlias('@fbbcbase/app/appbdmin/modules/Catalog/views') . DIRECTORY_SEPARATOR . $this->id;
    //}
}
