<?php
/**
 * FecMall file.
 * doc:https://packagist.org/packages/hightman/xunsearch.
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */
return [
    // yii class rewrite map
    'yiiClassMap' => [
        // 'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',
    ],
    // 重写model和block
    'fecRewriteMap' => [
        '\fecshop\app\apphtml5\modules\Customer\block\account\Index'  => '\fecwbbc\app\apphtml5\modules\Customer\block\account\Index',
        '\fecshop\app\apphtml5\modules\Payment\block\paypal\standard\Start'  => '\fecwbbc\app\apphtml5\modules\Payment\block\paypal\standard\Start',
        '\fecshop\app\apphtml5\modules\Payment\block\success\Index'  => '\fecwbbc\app\apphtml5\modules\Payment\block\success\Index',
       // '\fecshop\app\apphtml5\modules\Catalog\block\product\Index'  => '\fecwbbc\app\apphtml5\modules\Catalog\block\product\Index',
        '\fecshop\app\apphtml5\modules\Catalog\block\category\Price'  => '\fecwbbc\app\apphtml5\modules\Catalog\block\category\Price' ,
        
        //'\fecshop\app\appfront\modules\Catalog\block\category\Index'  => '\fecwbbc\app\appfront\modules\Catalog\block\category\Index',
        // '\fecshop\app\appfront\modules\Customer\block\address\Edit'  => '\fectb\app\appfront\modules\Customer\block\address\Edit',
    ],
    'components' => [
        // yii2 语言组件配置，关于Yii2国际化，可以参看：http://www.yiichina.com/doc/guide/2.0/tutorial-i18n
        'i18n' => [
            'translations' => [
                'apphtml5' => [
                    'basePaths' => [
                        '@fecwbbc/app/apphtml5/languages',
                    ],
                ],
            ],
        ],
    ],
    'modules' => [
        'site' => [
            'controllerMap' => [
                'page' => 'fecwbbc\app\apphtml5\modules\Site\controllers\PageController',  
            ],
        ],
        'customer' => [
            'controllerMap' => [
                'account' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\AccountController',  
                'contacts' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\ContactsController',  
                'editaccount' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\EditaccountController',  
                'editpassword' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\EditpasswordController',  
                'productfavorite' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\ProductfavoriteController',  
                'productreview' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\ProductreviewController',  
                'order' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\OrderController',  
                'address' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\AddressController',  
                'ajax' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\AjaxController',
                'coupon' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\CouponController',  
                'wx' => 'fecwbbc\app\apphtml5\modules\Customer\controllers\WxController',  
            ], 
        ],
        'catalogsearch'  => [
            'controllerMap' => [
                'text' => 'fecwbbc\app\apphtml5\modules\Catalogsearch\controllers\TextController',  
                'index' => 'fecwbbc\app\apphtml5\modules\Catalogsearch\controllers\IndexController',  
            ],
        ],
        'catalog' => [
            'controllerMap' => [
                'categorylist' => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\CategorylistController',        
                'category'      => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\CategoryController',   
                'favoriteproduct' => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\FavoriteproductController', 
                'reviewproduct'      => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\ReviewproductController',     
                'shop'      => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\ShopController',  
                'product' => 'fecwbbc\app\apphtml5\modules\Catalog\controllers\ProductController',  
            ],
        ],
        'checkout' => [
            'controllerMap' => [
                'onepage' => 'fecwbbc\app\apphtml5\modules\Checkout\controllers\OnepageController',    
                'cart' => 'fecwbbc\app\apphtml5\modules\Checkout\controllers\CartController',                                    
            ],
        ],
        'coupon' => [
            'class' => '\fecwbbc\app\apphtml5\modules\Coupon\Module',
        ],
        'payment' => [
            'controllerMap' => [
               // 'wxpayh5' => 'fecwbbc\app\apphtml5\modules\Payment\controllers\Wxpayh5Controller',    
               // 'wxpayjsapi' => 'fecwbbc\app\apphtml5\modules\Payment\controllers\WxpayjsapiController',   
                'checkmoney' => 'fecwbbc\app\appfront\modules\Payment\controllers\CheckmoneyController',  
                'success'   => 'fecwbbc\app\apphtml5\modules\Payment\controllers\SuccessController',           
            ],
        ],
    ],
    'services' => [
        'page' => [
            'childService' => [
                'widget' => [
                    'widgetConfig' => [
                        'base' => [
                            'header' => [
                                'class' => 'fecwbbc\app\apphtml5\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => 'widgets/header.php',
                                'cache' => [
                                    'timeout'    => 4500,
                                ],
                            ],
                            'header_shop' => [
                                'class' => 'fecwbbc\app\apphtml5\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => 'widgets/header_shop.php',
                                'cache' => [
                                    'timeout'    => 4500,
                                ],
                            ],
                            
                            
                            'header_search' => [
                                'class' => 'fecwbbc\app\apphtml5\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => 'widgets/header_search.php',
                                'cache' => [
                                    'timeout'    => 4500,
                                ],
                            ],
                            'afterContent' => [
                                'view'  => 'widgets/afterContent.php',
                            ],
                            /*
                            'header_navigation' => [
                                'view'  => 'widgets/header_navigation.php',
                            ],
                            'footer_navigation' => [
                                'view'  => 'widgets/footer_navigation.php',
                            ],
                           
                            'wx' => [
                                ///'class' => 'fecshop\app\appfront\widgets\Headers',
                                // 根据多模板的优先级，依次去模板找查找该文件，直到找到这个文件。
                                'view'  => '@fecwbbc/app/apphtml5/theme/fecwbbc/widgets/weixin.php',
                                //'cache' => [
                                //    'timeout'    => 4500,
                                //],
                            ],
                            */
                        ],
                        'category' => [
                            'price_favorite' => [
                                'class' 		=> 'fecshop\app\apphtml5\modules\Catalog\block\category\Price',
                                'view'  		=> 'catalog/category/price_favorite.php',
                            ],
                            'productlist' => [
                                'view'  => 'catalog/category/productlist.php',
                            ],
                            'quick_view' => [
                                'view'  => 'catalog/category/index/quick_view.php',
                            ],
                            'product_options' => [
                                'view'    => 'catalog/category/index/options.php'
                            ],
                        ],
                        'product' => [
                            'coupon' => [
                                'view'  => 'catalog/product/index/coupon.php',
                            ],
                            'reviewlist' => [
                                'view'  => 'catalog/reviewproduct/reviewlist.php',
                            ],
                            'quick_view' => [
                                'view'  => 'catalog/product/index/quick_view.php',
                            ],
                            'share_bar' => [
                                'view'  => 'catalog/product/index/share_bar.php',
                            ],
                            'shipping_payment' => [
                                'view'  => 'catalog/product/index/shipping_payment.php',
                            ],
                            
                            'price' => [
                                'class'         => 'fecwbbc\app\apphtml5\modules\Catalog\block\category\Price',
                                'view'        => 'catalog/product/index/price.php'
                            ],
                            'coupon' => [
                                'view'  => 'catalog/product/index/coupon.php',
                            ],
                        ],
                        'cart' => [
                            'quick_view' => [
                                'view'  => 'checkout/cart/index/quick_view.php',
                            ],
                        ],
                        'review' => [
                            'productlist' => [
                                'view'  => 'customer/productreview/productlist.php',
                            ],
                        ],
                        'favorite' => [
                            'productlist' => [
                                'view'  => 'customer/productfavorite/productlist.php',
                            ],
                            'product_price' => [
                                'class'         => 'fecwbbc\app\apphtml5\modules\Catalog\block\category\Price',
                                'view'  => 'customer/productfavorite/price.php',
                            ],
                        ],
                        'order' => [
                            'coupon' => [
                                'view'  => 'checkout/onepage/index/coupon.php',
                            ],
                        ],
                    ],
                    
                ],
                
            ],
        ],
    ],
];