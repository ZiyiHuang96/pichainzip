<?php

namespace fecwbbc\app\apphtml5\widgets;

use fecshop\interfaces\block\BlockCache;
use Yii;

class Headers implements BlockCache
{
    public function getLastData()
    {
        $currentUrl = Yii::$service->url->getCurrentUrl();
        $logoutUrl = Yii::$service->url->getUrl('customer/account/logout', ['rt'=>base64_encode($currentUrl)]);
        //$currentUrl = Yii::$service->url->getCurrentUrl();
        $currentUrlBase64 = base64_encode($currentUrl);
        $langUrl = Yii::$service->url->getUrl('site/page/lang', ['origin_url' => $currentUrlBase64]);
        $currencyUrl = Yii::$service->url->getUrl('site/page/currency', ['origin_url' => $currentUrlBase64]);
        
        //$currentLang =
        //$currency = Yii::$service->page->currency->getCurrentCurrency();
        return [
            'logoutUrl'            => $logoutUrl,
            'homeUrl'            => Yii::$service->url->homeUrl(),
            'currentBaseUrl'    => Yii::$service->url->getCurrentBaseUrl(),
            'logoImgUrl'      => Yii::$service->image->getLogoImgUrl(),
            'menuArr'  => $this->getMenuArr(),
            'langUrl' => $langUrl,
            'currencyUrl' => $currencyUrl,
            
        ];
    }
    
    
    
    public function getMenuArr()
    {
        $categoryStatus = Yii::$service->category->getCategoryEnableStatus();
        $cateId = Yii::$service->category->getPrimaryKey();
        $filter = [
            'select' => [$cateId, 'name', ],  // 'url_key'
            'asArray' => true,
            'fetchAll' => true,
            'where' => [
                ['parent_id' => 0],
                ['status' => $categoryStatus ],
            ],
            'orderBy'	=> ['sort_order' => SORT_DESC ],
        ];
        
        $data = Yii::$service->category->coll($filter);
        if (!is_array($data['coll']) || empty($data['coll'])) {
            
            return [];
        }
        $arr = [];
        foreach ($data['coll'] as $one) {
            $category_id = $one[$cateId];
            $category_name = Yii::$service->store->getStoreAttrVal($one['name'], 'name');
            $url = Yii::$service->url->getUrl('catalog/categorylist', ['top_cate_id' => $category_id]);
            $arr[] = [
                'category_id' => $category_id,
                'category_name' => $category_name,
                'url' => $url,
            ];
        }
        
        return $arr;
    }

    public function getCacheKey()
    {
        $lang = Yii::$service->store->currentLangCode;
        $currency = Yii::$service->page->currency->getCurrentCurrency();
        $appName        = Yii::$service->helper->getAppName();
        $cacheKeyName   = 'footer';
        $currentStore   = Yii::$service->store->currentStore;
        return self::BLOCK_CACHE_PREFIX.'_'.$currentStore.'_'.$lang.'_'.$currency.'_'.$appName.'_'.$cacheKeyName;
    }
}
