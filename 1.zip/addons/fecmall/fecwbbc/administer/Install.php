<?php
/**
 * Fecmall Addons
 */
namespace fecwbbc\administer;
use Yii;
/**
 * 应用安装类
 * 您可以在这里添加类变量，在配置中的值可以注入进来。
 */
class Install implements \fecshop\services\extension\InstallInterface
{
    // 安装初始版本号，不需要改动，不能为空
    public $version = '1.0.0';
    // 类变量，在config.php中可以通过配置注入值
    public $test;
    
    /**
     * @return mixed|void
     */
    public function run()
    {
        if (!$this->installDbSql()) {
            return false;
        }
        if (!$this->copyImageFile()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 进行数据库的初始化
     * sql语句执行，多个sql用分号  `;`隔开
     */
    public function installDbSql()
    {
        $db = Yii::$app->getDb();
        
        // 1
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Fecbbc Config Manager', 'config_fecbbc_manager', 1, '/config/fecbbc/manager', 1572925266, 1572925266, 1)"
        )->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 2
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Fecbbc Config Manager Save', 'config_fecbbc_manager', 2, '/config/fecbbc/managersave', 1572925393, 1572925393, 1)"
        )->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        
        /////////////////////
        // 1
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Account List', 'supplier-account', 1, '/supplier/account/index', 1552012790, 1552133760, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
         $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();

        // 2
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Account Edit', 'supplier-account', 2, '/supplier/account/manageredit', 1552130585, 1552133755, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 3
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Account Save', 'supplier-account', 3, '/supplier/account/managereditsave', 1552130619, 1552133749, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 4
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Account Delete', 'supplier-account', 4, '/supplier/account/managerdelete', 1552130667, 1552133742, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 5
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Order After Sale Return List', 'order-after-sale', 1, '/sales/returnlist/manager', 1553477824, 1553477824, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 6
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Order After Sale Return Info', 'order-after-sale', 2, '/sales/returnlist/manageredit', 1553477852, 1553477852, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 7
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Admin Refund List', 'order-refund', 1, '/sales/refund/manager', 1553477914, 1553477914, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 8
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Admin Refund Edit', 'order-refund', 2, '/sales/refund/manageredit', 1553477996, 1553477996, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 9
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Admin Refund Save', 'order-refund', 3, '/sales/refund/managersave', 1553478031, 1553478031, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 10
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Admin Refund Accept', 'order-refund', 4, '/sales/refund/manageraccept', 1553478064, 1553478064, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        
        // 11
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Bdmin Refund', 'order-refund', 6, '/sales/refundbdmin/manager', 1553478105, 1553502711, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 12
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Order Settle', 'order-statistics', 1, '/sales/ordersettle/manager', 1553653551, 1553653551, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 12-2
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Order Settle Edit', 'order-statistics', 3, '/sales/ordersettle/manageredit', 1579187795, 1579187795, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        
        // 13
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Home Page Config', 'config-homepage', 1, '/cms/homepage/manager', 1554107046, 1554117146, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 14
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Home Page Config Save', 'config-homepage', 2, '/cms/homepage/managereditsave', 1554107065, 1554117214, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 15
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Base Info Config', 'config-baseinfo', 1, '/cms/baseinfo/manager', 1554117085, 1554117085, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 16
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Base Info Config Save', 'config-baseinfo', 2, '/cms/baseinfo/managereditsave', 1554117204, 1554117204, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        // 17
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Order Operate Log', 'order-log', 1, '/sales/orderlog/manager', 1554818927, 1554818927, 1)")->execute();
        
        $lastInsertId = $db->getLastInsertID() ;
        
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1541129239, 1541129239)")->execute();
        
        /////////////////////////////
         $arr = [
            "
            CREATE TABLE IF NOT EXISTS `bdmin_user` (
              `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
              `username` varchar(50) DEFAULT NULL COMMENT '用户名',
              `password_hash` varchar(80) DEFAULT NULL COMMENT '密码',
              `password_reset_token` varchar(60) DEFAULT NULL COMMENT '密码token',
              `email` varchar(60) DEFAULT NULL COMMENT '邮箱',
              `person` varchar(100) DEFAULT NULL COMMENT '用户姓名',
              `code` varchar(100) DEFAULT NULL,
              `auth_key` varchar(60) DEFAULT NULL,
              `status` int(5) DEFAULT NULL COMMENT '状态',
              `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
              `updated_at` int(11) DEFAULT NULL COMMENT '更新时间',
              `password` varchar(50) DEFAULT NULL COMMENT '密码',
              `access_token` varchar(60) DEFAULT NULL,
              `access_token_created_at` int(11) DEFAULT NULL COMMENT 'access token 的创建时间，格式为Int类型的时间戳',
              `allowance` int(11) DEFAULT NULL,
              `allowance_updated_at` int(11) DEFAULT NULL,
              `created_at_datetime` datetime DEFAULT NULL,
              `updated_at_datetime` datetime DEFAULT NULL,
              `birth_date` datetime DEFAULT NULL COMMENT '出生日期',
              PRIMARY KEY (`id`),
              UNIQUE KEY `username` (`username`),
              UNIQUE KEY `access_token` (`access_token`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;
            "
            ,
            
            "
            ALTER TABLE  `customer` ADD  `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '该用户所属的供应商的id', ADD INDEX (  `bdmin_user_id` )
            "
            ,
            "
            ALTER TABLE  `sales_flat_order` ADD  `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '供应商的id' AFTER  `customer_id` , ADD INDEX (  `bdmin_user_id` )
            "
            ,
            "
            ALTER TABLE  `sales_flat_order_item` ADD  `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '供应商的id' AFTER  `customer_id` ,ADD INDEX (  `bdmin_user_id` )
            "
            ,
            "
            ALTER TABLE  `sales_flat_order` CHANGE  `order_status`  `order_status` VARCHAR( 80 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT  '订单流程状态'
            "
            ,
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `order_operate_status` VARCHAR( 80 ) NULL COMMENT  '订单操作状态' AFTER  `order_status`
            ",
            
            "
            ALTER TABLE  `sales_flat_order_item` ADD  `item_status` VARCHAR( 80 ) NULL COMMENT  '订单商品状态，退款，换货等状态'
            ",
            "
            CREATE TABLE IF NOT EXISTS `sales_flat_order_after_sale` (
                `id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                `order_id` INT( 11 ) NOT NULL ,
                `item_id` INT( 11 ) NOT NULL ,
                `sku` VARCHAR( 100 ) NULL ,
                `price` DECIMAL( 12, 2 ) NULL ,
                `qty` INT( 11 ) NULL ,
                `tracking_number` VARCHAR( 100 ) NULL ,
                `created_at` INT( 11 ) NULL ,
                `updated_at` INT( 11 ) NULL
                ) ENGINE = INNODB; 
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `status` VARCHAR( 50 ) NOT NULL COMMENT  '退款状态' AFTER  `item_id` , ADD INDEX (  `status` )
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `bdmin_user_id` INT( 11 ) NULL COMMENT  '供应商id' AFTER  `order_id` , ADD INDEX (  `bdmin_user_id` )
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `customer_id` INT( 11 ) NULL AFTER  `bdmin_user_id` , ADD INDEX (  `customer_id` )
            ",
            
            "
           ALTER TABLE  `sales_flat_order_after_sale` ADD  `base_price` DECIMAL( 12, 2 ) NULL AFTER  `price` 
            ",
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `image` VARCHAR( 255 ) NULL AFTER  `sku` 
            ",
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `product_id` VARCHAR( 100 ) NULL AFTER  `sku`
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `custom_option_sku` VARCHAR( 100 ) NULL AFTER  `sku`
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `currency_code` VARCHAR( 20 ) NULL AFTER  `product_id` 
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `order_to_base_rate` DECIMAL( 12, 4 ) NULL COMMENT  '汇率' AFTER  `currency_code` 
            ",
            
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `increment_id` VARCHAR( 50 ) NULL AFTER  `order_id` 
            ",
            "
            ALTER TABLE  `sales_flat_order_after_sale` ADD  `payment_method` VARCHAR( 50 ) NULL AFTER  `increment_id`
            ",
            
            "
            CREATE TABLE IF NOT EXISTS `refund_bdmin` (
                `id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '供应商id',
                `as_id` INT( 11 ) NULL COMMENT  'after sale id',
                `increment_id` VARCHAR( 50 ) NULL ,
                `price` DECIMAL( 12, 2 ) NULL ,
                `base_price` DECIMAL( 12, 2 ) NULL ,
                `currency_code` VARCHAR( 20 ) NULL ,
                `order_to_base_rate` DECIMAL( 12, 2 ) NULL ,
                `customer_id` INT( 11 ) NULL ,
                `customer_bank_name` VARCHAR( 50 ) NULL ,
                `customer_bank_account` VARCHAR( 100 ) NULL ,
                `created_at` INT( 11 ) NULL ,
                `updated_at` INT( 11 ) NULL ,
                `type` VARCHAR( 60 ) NULL COMMENT  '退款的类型',
                INDEX (  `bdmin_user_id` )
                ) ENGINE = INNODB; 
            ",
            
            "
            CREATE TABLE IF NOT EXISTS `refund_admin` (
                `id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '供应商id',
                `as_id` INT( 11 ) NULL COMMENT  'after sale id',
                `increment_id` VARCHAR( 50 ) NULL ,
                `price` DECIMAL( 12, 2 ) NULL ,
                `base_price` DECIMAL( 12, 2 ) NULL ,
                `currency_code` VARCHAR( 20 ) NULL ,
                `order_to_base_rate` DECIMAL( 12, 2 ) NULL ,
                `customer_id` INT( 11 ) NULL ,
                `customer_bank_name` VARCHAR( 50 ) NULL ,
                `customer_bank_account` VARCHAR( 100 ) NULL ,
                `created_at` INT( 11 ) NULL ,
                `updated_at` INT( 11 ) NULL ,
                `type` VARCHAR( 60 ) NULL COMMENT  '退款的类型',
                INDEX (  `bdmin_user_id` )
                ) ENGINE = INNODB; 
            ",
            
            "
            ALTER TABLE  `refund_admin` ADD  `customer_bank` VARCHAR( 100 ) NULL AFTER  `customer_bank_name` 
            ",
            
            "
            ALTER TABLE  `refund_bdmin` ADD  `customer_bank` VARCHAR( 100 ) NULL AFTER  `customer_bank_name` 
            ",
            
            "
            ALTER TABLE  `customer` ADD  `customer_bank` VARCHAR( 100 ) NULL COMMENT  '银行名称（银行，支付宝，微信）',
            ADD  `customer_bank_name` VARCHAR( 100 ) NULL COMMENT  '银行账户对应的姓名',
            ADD  `customer_bank_account` VARCHAR( 100 ) NULL COMMENT  '银行账户'
            ",
            
                
            "
            ALTER TABLE  `bdmin_user` ADD  `bdmin_bank` VARCHAR( 100 ) NULL COMMENT  '银行名称（银行，支付宝，微信）',
            ADD  `bdmin_bank_name` VARCHAR( 100 ) NULL COMMENT  '银行账户对应的姓名',
            ADD  `bdmin_bank_account` VARCHAR( 100 ) NULL COMMENT  '银行账户'
           ",
            
            "
            ALTER TABLE  `refund_admin` ADD  `status` VARCHAR( 50 ) NULL 
            ",
            
            "
            ALTER TABLE  `refund_bdmin` ADD  `status` VARCHAR( 50 ) NULL 
            ",
            
            "
            ALTER TABLE  `refund_admin` ADD  `customer_email` VARCHAR( 100 ) NULL AFTER  `customer_id` 
            ",
            
            "
            ALTER TABLE  `refund_bdmin` ADD  `customer_email` VARCHAR( 100 ) NULL AFTER  `customer_id` 
            ",
            "
            ALTER TABLE  `refund_admin` ADD  `refunded_at` INT( 11 ) NULL COMMENT  '退款时间' AFTER  `updated_at`
            ",
            "
            ALTER TABLE  `refund_bdmin` ADD  `refunded_at` INT( 11 ) NULL COMMENT  '退款时间' AFTER  `updated_at`
            ",
            
            "
            CREATE TABLE IF NOT EXISTS `statistical_bdmin_month` (
                `id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                `bdmin_user_id` INT( 11 ) NOT NULL COMMENT  '供应商ID',
                `complete_order_total` DECIMAL( 12, 2 ) NULL COMMENT  '完成的订单金额',
                `refund_return_total` DECIMAL( 12, 2 ) NULL COMMENT  '退货-退款总额',
                `month` INT( 5 ) NULL COMMENT  '月份',
                `updated_at` INT( 11 ) NULL COMMENT  '更新时间',
                `created_at` INT( 11 ) NULL COMMENT  '创建时间'
                ) ENGINE = INNODB;
            ",
            //"
            //ALTER TABLE  `sales_flat_order` ADD  `received_at` INT( 11 ) NULL COMMENT  '用户订单收货时间' AFTER  `updated_at`
            //",
            
            "
            ALTER TABLE  `statistical_bdmin_month` ADD  `year` INT( 5 ) NULL AFTER  `month`
            ",
            
            "
            ALTER TABLE  `statistical_bdmin_month` ADD  `month_total` DECIMAL( 12, 2 ) NULL COMMENT  '月结算金额 = 订单总额 - 退款总额' AFTER  `refund_return_total`
            ",
            
            "
            ALTER TABLE  `statistical_bdmin_month` CHANGE  `refund_return_total`  `admin_refund_return_total` DECIMAL( 12, 2 ) NULL DEFAULT NULL COMMENT  '平台退货-退款总额'
            " ,
            "
            ALTER TABLE  `statistical_bdmin_month` ADD  `bdmin_refund_return_total` DECIMAL( 12, 2 ) NULL COMMENT  '供应商退款(货到付款类型的订单退款)-退款总额' AFTER  `admin_refund_return_total`
            ",
            
            "
            ALTER TABLE  `statistical_bdmin_month` CHANGE  `month_total`  `month_total` DECIMAL( 12, 2 ) NULL DEFAULT NULL COMMENT  '月结算金额 = 完成订单总额 - 平台退货-退款总额'
            ",
            
            //"
            //ALTER TABLE  `customer_address` ADD  `area` VARCHAR( 50 ) NULL COMMENT  '城市对应的区' AFTER  `city`
            //",
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `customer_address_area` VARCHAR( 50 ) NULL COMMENT  '订单地址城市对应的区' AFTER  `customer_address_city`
            ",
            
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `dispatched_at` INT( 11 ) NULL COMMENT  '订单的发货时间' AFTER  `updated_at`
            ",
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `recevie_delay_days` INT( 11 ) NULL COMMENT  '收货时间延迟的天数，用户可以发起延迟收货天数的操作' AFTER  `dispatched_at`
            ",
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `bdmin_audit_acceptd_at` INT( 11 ) NULL COMMENT  '供应商审核通过的时间' AFTER  `updated_at`
            ",
            
            "
            ALTER TABLE  `customer` CHANGE  `bdmin_user_id`  `bdmin_user_id` INT( 11 ) NULL COMMENT  '该用户所属的供应商的id'
            ",
            "
            ALTER TABLE  `customer` ADD  `phone` VARCHAR( 20 ) NULL COMMENT  '手机号' AFTER  `email`
            ",
            
            "
            ALTER TABLE  `bdmin_user` ADD  `uuid` VARCHAR( 100 ) NULL COMMENT  '供应商的唯一编码', ADD UNIQUE (`uuid`)
            ",
        ];
    
        foreach ($arr as $sql) {
            $db->createCommand($sql)->execute();
        }
        
        
        // 订单产品表-增加评论字段
        $db->createCommand(
            "ALTER TABLE `sales_flat_order_item` ADD `is_reviewed` INT( 5 ) NULL DEFAULT '2' COMMENT '1代表已经评论，2代表未评论'"
        )->execute();
        // 订单表-增加评论字段
        $db->createCommand(
            "ALTER TABLE `sales_flat_order` ADD `is_reviewed` INT( 5 ) NULL DEFAULT '2' COMMENT '1代表已经评论，2代表未评论'"
        )->execute();
        
        // 订单表-增加评论字段
        $db->createCommand(
            "
            ALTER TABLE `sales_flat_order` 
            ADD `received_at` INT( 12 ) NULL COMMENT '订单收货时间',
            ADD `reviewed_at` INT( 12 ) NULL COMMENT '订单评论时间'
            "
        )->execute();
        
        
        
        
        ////////////////////////////
        $arr = [
            
            '
            INSERT INTO `bdmin_user` (`id`, `username`, `password_hash`, `password_reset_token`, `email`, `person`, `code`, `auth_key`, `status`, `created_at`, `updated_at`, `password`, `access_token`, `access_token_created_at`, `allowance`, `allowance_updated_at`, `created_at_datetime`, `updated_at_datetime`, `birth_date`, `bdmin_bank`, `bdmin_bank_name`, `bdmin_bank_account`, `uuid`) VALUES
(3, \'fecshop\', \'$2y$13$sR7jfcfHULF9sSx9VY70auBZob9kGI1skGLBB1CDX5SiXrswBqFzO\', NULL, \'2358269014@qq.com\', \'terry\', NULL, \'EzZd2MFyeS3nkyZ1QX4FvsQnlHelfbzM\', 1, NULL, NULL, \'\', \'Kfyho3dAwWSRxUopzZ_OPzaQSsl-25Jg\', NULL, NULL, NULL, \'2019-05-09 12:33:31\', \'2019-05-09 12:33:31\', NULL, NULL, NULL, NULL, \'9928e826-7213-11e9-8dd4-00163e021360\');
            '
            ,
            
            "
            ALTER TABLE  `sales_flat_order` CHANGE  `bdmin_user_id`  `bdmin_user_id` INT( 11 ) NULL COMMENT  '供应商的id'
            ",
            
            "
            ALTER TABLE  `sales_flat_order_item` CHANGE  `bdmin_user_id`  `bdmin_user_id` INT( 11 ) NULL COMMENT  '供应商的id'
            ",
            
            "
            ALTER TABLE  `sales_flat_order` ADD  `payment_no` VARCHAR( 50 ) NULL COMMENT  '订单交易编码' AFTER  `order_id` , ADD INDEX (  `payment_no` )
            ",
            
            "
            ALTER TABLE  `sales_flat_order` CHANGE  `payment_no`  `payment_no` VARCHAR( 150 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT  '订单交易编码'
            ",
            "
            ALTER TABLE  `sales_flat_order` CHANGE  `payment_method`  `payment_method` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT  '支付方式'
            ",
            "
            ALTER TABLE  `sales_flat_order` CHANGE  `shipping_method`  `shipping_method` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT  '货运方式'
            ",
            // mysql add  bdmin_user_id
            "
                ALTER TABLE `product_flat` ADD `bdmin_user_id` INT( 12 ) NOT NULL COMMENT '经销商id', ADD INDEX ( `bdmin_user_id` )
            ",
            "
                ALTER TABLE `review` ADD `bdmin_user_id` INT( 12 ) NULL COMMENT '经销商id', ADD INDEX ( `bdmin_user_id` )
            ",
            "
                ALTER TABLE `favorite` ADD `bdmin_user_id` INT( 12 ) NOT NULL , ADD INDEX ( `bdmin_user_id` )
            ",
            
             
            "
                ALTER TABLE `sales_flat_order_after_sale` ADD `tracking_company` VARCHAR( 30 ) NULL COMMENT '物流公司' AFTER `tracking_number`
            ",
        
            ];
    
        foreach ($arr as $sql) {
            $db->createCommand($sql)->execute();
        }
        
        
        
        $db->createCommand(
            "
            CREATE TABLE IF NOT EXISTS `sales_order_process_log` (
                `id` INT( 12 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                `created_at` INT( 12 ) NULL ,
                `updated_at` INT( 12 ) NULL ,
                `order_id` INT( 12 ) NULL ,
                `increment_id` VARCHAR( 50 ) NULL ,
                `customer_id` INT( 12 ) NULL ,
                `bdmin_user_id` INT( 12 ) NULL ,
                `type` VARCHAR( 50 ) NULL ,
                INDEX ( `order_id` , `bdmin_user_id` )
                ) ENGINE = INNODB;

            "
        )->execute();
        
        $sql = "
            ALTER TABLE `product_flat` ADD `is_deputy` INT( 5 ) NULL DEFAULT NULL COMMENT 'spu的后台展示。是否代表产品，1代表是代表产品，2代表不是代表产品', ADD INDEX ( `is_deputy` )
           ";
        $db->createCommand($sql)->execute();
        
        $sql = "
            UPDATE `admin_url_key` SET `url_key` = '/sales/refund/managereditsave' WHERE `url_key` = '/sales/refund/managersave';
            ";
        $db->createCommand($sql)->execute();
        
        // 1
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Config Fecphone Manager', 'config_fecphone', 1, '/config/fecphone/manager', 1581670328, 1581670328, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 2
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Config Fecphone Save', 'config_fecphone', 2, '/config/fecphone/managersave', 1581670374, 1581670374, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        $db->createCommand(
            "
            ALTER TABLE `customer` ADD UNIQUE (`phone`)
            "
        )->execute();
        
        $db->createCommand(
            "
                CREATE TABLE `customer_wx_qr_code_log` (
                    `id` INT( 12 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
                    `openid` VARCHAR( 120 ) NULL ,
                    `eventkey` VARCHAR( 50 ) NULL ,
                    `created_at` INT( 12 ) NULL ,
                    `updated_at` INT( 12 ) NULL ,
                    UNIQUE (
                    `openid` ,
                    `eventkey`
                    )
                ) ENGINE = INNODB;
            "
        )->execute();
        
        
        $db->createCommand(
            "
                ALTER TABLE `customer` ADD `wx_password_is_set` INT( 5 ) NULL DEFAULT '1' COMMENT '1代表已经设置密码，2代表未设置密码'
            "
        )->execute();
        
        
        $db->createCommand(
            "
                CREATE TABLE IF NOT EXISTS `bdmin_coupon` (
                  `id` int(12) NOT NULL AUTO_INCREMENT COMMENT '主键',
                  `code` varchar(100) DEFAULT NULL COMMENT '优惠券编码',
                  `name` varchar(150) DEFAULT NULL COMMENT '优惠券名称',
                  `total_count` int(12) DEFAULT NULL COMMENT '优惠券总数',
                  `assign_count` int(12) DEFAULT '0' COMMENT '优惠券发放数',
                  `discount_cost` decimal(12,2) DEFAULT NULL COMMENT '优惠金额',
                  `use_condition` decimal(12,2) DEFAULT NULL COMMENT '使用门槛',
                  `condition_product_type` varchar(30) DEFAULT NULL COMMENT '优惠券产品限制类型：all代表经销商所有产品可用，sku代表指定的产品列表可用，category代表该分类下，该分销商的产品',
                  `condition_product_skus` text COMMENT '当condition_product_type为sku的时候，该字段有效，sku为英文逗号隔开的字符串，并且开头结尾都有，类似于   `sku1,sku2,sku3`,这样做的用意是为了可以通过模糊匹配搜索优惠券',
                  `condition_product_category_ids` text COMMENT '当condition_product_type为category的时候有效',
                  `assign_begin_at` int(12) DEFAULT NULL COMMENT '优惠券的发放有效开始时间',
                  `assign_end_at` int(12) DEFAULT NULL COMMENT '优惠券的发放有效结束时间',
                  `created_at` int(12) DEFAULT NULL COMMENT '优惠券创建时间',
                  `updated_at` int(12) DEFAULT NULL COMMENT '优惠券更新时间',
                  `bdmin_user_id` int(12) DEFAULT NULL COMMENT '经销商id',
                  `remark` varchar(200) DEFAULT NULL COMMENT '优惠券备注',
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `code` (`code`),
                  KEY `bdmin_user_id` (`bdmin_user_id`,`assign_end_at`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
            "
        )->execute();
        
        
        $db->createCommand(
            "
                CREATE TABLE IF NOT EXISTS `customer_coupon` (
                  `id` int(12) NOT NULL AUTO_INCREMENT,
                  `customer_id` int(12) DEFAULT NULL COMMENT '用户id',
                  `coupon_id` int(12) DEFAULT NULL COMMENT '优惠券id',
                  `name` text COMMENT '优惠券名称',
                  `code` varchar(100) DEFAULT NULL COMMENT '优惠券卷码',
                  `bdmin_user_id` int(12) DEFAULT NULL COMMENT '经销商id',
                  `discount_cost` decimal(12,2) DEFAULT NULL COMMENT '优惠金额',
                  `use_condition` decimal(12,2) DEFAULT NULL COMMENT '使用门槛',
                  `condition_product_type` varchar(30) DEFAULT NULL COMMENT '优惠券产品限制类型：all代表经销商所有产品可用，sku代表指定的产品列表可用，category代表该分类下，该分销商的产品',
                  `condition_product_skus` text COMMENT '当condition_product_type为sku的时候，该字段有效，sku为英文逗号隔开的字符串，并且开头结尾都有，类似于   `sku1,sku2,sku3`,这样做的用意是为了可以通过模糊匹配搜索优惠券。',
                  `condition_product_category_ids` text COMMENT '当condition_product_type为category的时候有效，分类id',
                  `active_begin_at` int(12) DEFAULT NULL COMMENT '优惠券的有效开始时间',
                  `active_end_at` int(12) DEFAULT NULL COMMENT '优惠券的有效结束时间',
                  `is_used` int(5) DEFAULT NULL COMMENT '是否被使用，1代表已经被使用，2代表未使用',
                  `created_at` int(12) DEFAULT NULL COMMENT '创建时间',
                  `updated_at` int(12) DEFAULT NULL COMMENT '更新时间',
                  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `customer_id` (`customer_id`,`code`),
                  KEY `bdmin_user_id` (`bdmin_user_id`,`active_end_at`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
            "
        )->execute();
        
        $db->createCommand(
            "
                CREATE TABLE IF NOT EXISTS `store_bdmin_config` (
                  `id` int(12) NOT NULL AUTO_INCREMENT,
                  `key` varchar(100) NOT NULL,
                  `value` text NOT NULL,
                  `bdmin_user_id` int(12) NOT NULL,
                  `created_at` int(12) NOT NULL,
                  `updated_at` int(12) NOT NULL,
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `bdmin_user_id` (`bdmin_user_id`,`key`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
            "
        )->execute();
        
        $db->createCommand(
            "
                CREATE TABLE IF NOT EXISTS `customer_sms_code` (
                  `id` int(12) NOT NULL AUTO_INCREMENT,
                  `key` varchar(80) DEFAULT NULL COMMENT '验证码类型',
                  `phone` varchar(39) DEFAULT NULL COMMENT '验证码手机',
                  `code` varchar(20) DEFAULT NULL COMMENT '验证码字符串',
                  `created_at` int(12) DEFAULT NULL,
                  `updated_at` int(12) DEFAULT NULL,
                  PRIMARY KEY (`id`),
                  KEY `phone` (`phone`,`code`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
            "
        )->execute();
        
        $db->createCommand(
            "
                ALTER TABLE `bdmin_coupon` ADD `is_show_in_product_page` INT( 5 ) NOT NULL DEFAULT '1' COMMENT '是否在产品页面显示该优惠券，1代表显示，2代表不显示'
            "
        )->execute();
        
        $db->createCommand(
            "
                ALTER TABLE `customer` ADD `sex` INT( 5 ) NULL COMMENT '性别' AFTER `lastname`
            "
        )->execute();
        
        
        $db->createCommand(
            "
                ALTER TABLE `bdmin_user` ADD `telephone` VARCHAR( 50 ) NULL COMMENT '电话',
                ADD `tax_point` DECIMAL( 12, 2 ) NULL COMMENT '税点',
                ADD `invoice` VARCHAR( 100 ) NULL COMMENT '发票要求',
                ADD `authorized_brand` VARCHAR( 100 ) NULL COMMENT '授权品牌',
                ADD `authorized_type` INT( 5 ) NULL COMMENT '授权类型',
                ADD `authorized_role` INT( 5 ) NULL COMMENT '授权权限',
                ADD `authorized_at` INT( 12 ) NULL COMMENT '授权书有效期',
                ADD `cooperationed_at` INT( 12 ) NULL COMMENT '合作协议有效期',
                ADD `is_audit` INT( 5 ) NULL COMMENT '审核状态，1代表通过，2代表等待审核，3代表审核拒绝',
                ADD `shipping_date` VARCHAR( 150 ) NULL COMMENT '发货时效',
                ADD `order_date` VARCHAR( 150 ) NULL COMMENT '截单时间',
                ADD `remark` VARCHAR( 150 ) NULL COMMENT '备注',
                ADD `zip_file` VARCHAR( 150 ) NULL COMMENT '其他',
                ADD `audit_at` INT( 12 ) NULL COMMENT '审核时间'
            "
        )->execute();
        
        // 1
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Apply List', 'supplier-apply', 1, '/supplier/apply/manager', 1612015992, 1612015992, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 2
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Apply View', 'supplier-apply', 2, '/supplier/apply/manageredit', 1612016024, 1612016024, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 3
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Apply Accept', 'supplier-apply', 3, '/supplier/apply/manageraccept', 1612016080, 1612016080, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 4
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Apply Refuse', 'supplier-apply', 4, '/supplier/apply/managerrefuse', 1612016111, 1612016111, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        // 5
        $db->createCommand(
            "INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ('Supplier Apply Download Zip', 'supplier-apply', 5, '/supplier/apply/downloadzip', 1612018662, 1612018662, 1)"
        )->execute();

        $lastInsertId = $db->getLastInsertID() ;

        $db->createCommand(
            "INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1567162984, 1567162984)"
        )->execute();
        
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Product Bulk Enable', 'catalog_product_info_manager', 22, '/catalog/productinfo/bulkenable',1615859481,1615859481, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1615859481, 1615859481)")->execute();

        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Product Bulk Disable', 'catalog_product_info_manager', 23, '/catalog/productinfo/bulkdisable',1615859481,1615859481, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1615859481, 1615859481)")->execute();
        
        
        
        
        
        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Sales Order Offline-Pay Confirm', 'sales_order_manager', 22, '/sales/orderinfo/managerpayconfirm',1617081041,1617081041, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1617081041, 1617081041)")->execute();


        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Sales Order Offline-Pay Reject', 'sales_order_manager', 23, '/sales/orderinfo/managerpayreject',1617081041,1617081041, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1617081041, 1617081041)")->execute();


        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Config Payment Check-Order', 'config_payment_manager', 33, '/config/paymentcheckorder/manager',1617081041,1617081041, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1617081041, 1617081041)")->execute();


        $db->createCommand("INSERT INTO `admin_url_key` (`name`, `tag`, `tag_sort_order`, `url_key`, `created_at`, `updated_at`, `can_delete`) VALUES ( 'Config Payment Check-Order Save', 'config_payment_manager', 44, '/config/paymentcheckorder/managersave',1617081041,1617081041, 1)")->execute();
        $lastInsertId = $db->getLastInsertID() ;
        $db->createCommand("INSERT INTO `admin_role_url_key` (`role_id`, `url_key_id`, `created_at`, `updated_at`) VALUES (4, " . $lastInsertId . ", 1617081041, 1617081041)")->execute();


        
        $db->createCommand(
            "
                CREATE TABLE IF NOT EXISTS `bdmin_shipping_theme` (
                  `id` int(12) NOT NULL AUTO_INCREMENT,
                  `created_at` int(12) DEFAULT NULL,
                  `updated_at` int(12) DEFAULT NULL,
                  `bdmin_user_id` int(12) DEFAULT NULL,
                  `label` text,
                  `item_info` text COMMENT '运费模板对应的子项列表，序列化存储',
                  `is_default` int(5) DEFAULT NULL COMMENT '1代表默认物流，2代表非默认物流。',
                  PRIMARY KEY (`id`),
                  KEY `bdmin_user_id` (`bdmin_user_id`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

            "
        )->execute();
        
        
        $db->createCommand(
            "
                
                CREATE TABLE IF NOT EXISTS `bdmin_shipping_items` (
                  `id` int(12) NOT NULL AUTO_INCREMENT,
                  `bdmin_user_id` int(12) DEFAULT NULL COMMENT '经销商id',
                  `bdmin_shipping_id` int(12) DEFAULT NULL COMMENT '经销商运费模板表id',
                  `country_codes` varchar(255) DEFAULT NULL COMMENT '国家简码，多个国家简码请用逗号隔开',
                  `shipping_info` text COMMENT '运费详细，重量和对应的价格',
                  `updated_at` int(12) DEFAULT NULL COMMENT '更新时间',
                  `created_at` int(12) DEFAULT NULL COMMENT '创建时间',
                  PRIMARY KEY (`id`),
                  KEY `bdmin_shipping_id` (`bdmin_shipping_id`,`country_codes`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

            "
        )->execute();
        
        $db->createCommand(
            "
                ALTER TABLE `sales_flat_order` ADD `offline_pay_image` VARCHAR( 255 ) NULL COMMENT '线下转账凭证'
            "
        )->execute();
        
        return true;
    }
    
    
    /**
     * 复制图片文件到appimage/common/addons/{namespace}，如果存在，则会被强制覆盖
     */
    public function copyImageFile()
    {
        $sourcePath = Yii::getAlias('@fecwbbc/app/appimage/common/addons/fecwbbc');
        
        Yii::$service->extension->administer->copyThemeFile($sourcePath);
        
        return true;
    }
    
}