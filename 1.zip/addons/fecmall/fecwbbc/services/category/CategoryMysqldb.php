<?php

/*
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace fecwbbc\services\category;

use fecshop\models\mongodb\Category;
use fecshop\services\Service;
use Yii;

/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class CategoryMysqldb extends \fecshop\services\category\CategoryMysqldb
{
    /**
     * 得到当前分类的下两级分类
     */
    public function getChildTwoLevelCategory($category_id)
    {
        $categorys = $this->getChildCate($category_id);
        if (!is_array($categorys)) {
            
            return [];
        }
        foreach ($categorys as $k=>$category) {
            $c_id = $category['category_id'];
            if ($this->hasChildCategory($c_id)) {
                $categorys[$k]['child'] = $this->getChildCate($c_id);
            }
        }
        
        return $categorys;
    }
}