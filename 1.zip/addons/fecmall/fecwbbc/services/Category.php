<?php

/*
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace fecwbbc\services;

use Yii;
/**
 * Category service.
 *
 * @method coll($filters = [])
 * @see \fecshop\services\Category::actionColl()
 * @method getCategoryEnableStatus()
 * @see \fecshop\services\Category::actionGetCategoryEnableStatus()
 *
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class Category extends \fecshop\services\Category
{
    
    /**
     * 得到所有的子分类
     */
    public function getChildTwoLevelCategory($category_id)
    {
        return $this->_category->getChildTwoLevelCategory($category_id);
    }
    
    public function getFilterInfo($categoryM, $whereParam, $chosenAttrs = [])
    {
        $filter_info = [];
        $filter_attrs = $this->getFilterAttr($categoryM);
        //var_dump($filter_attrs);
        $customAttrInfo = $this->customCategoryFilterAttrInfo();
        if (is_array($filter_attrs) && !empty($filter_attrs)) {
            foreach ($filter_attrs as $attr) {
                if ($attr != 'price') {
                    $attrFilterItem = [];
                    $attrFilterItem['name'] = $attr;
                    $attrLabel = '';
                    // filter
                    //var_dump($attr);
                    //var_dump($whereParam);
                    $attrFilter = Yii::$service->product->getFrontCategoryFilter($attr, $whereParam);
                    if (isset($customAttrInfo[$attr]) && $customAttrInfo[$attr]) {
                        $attrLabel = $customAttrInfo[$attr]['label'];
                    }
                    // 非api入口
                    if (!Yii::$service->helper->isApiApp()) {
                        if (!$attrLabel) {
                            $attrLabel = Yii::$service->page->translate->__($attr);
                        }
                        $attrFilterItem['label'] = $attrLabel;
                        $attrUrlStr = Yii::$service->url->category->attrValConvertUrlStr($attr);
                    } else {
                        if (!$attrLabel) {
                            $attrLabel = preg_replace_callback('/([-_]+([a-z]{1}))/i',function($matches){
                                return ' '.strtoupper($matches[2]);
                            },$attr);
                        }
                        $attrFilterItem['label'] = $attrLabel;
                    }
                    $hasSelected = false;
                    $selectedVal = Yii::$service->page->translate->__('All');
                    // 处理items
                    if (is_array($attrFilter) && !empty($attrFilter)) {
                        //var_dump($attrFilter);
                        foreach ($attrFilter as $k=>$item) {
                            $itemName    = $item['_id'];
                            if (!$itemName) {
                                continue;
                            }
                            $itemLabel = $this->getCustomCategoryFilterAttrItemLabel($attr, $itemName);
                            // 非appapi入口
                            if (!Yii::$service->helper->isApiApp()) {
                                $count  = $item['count'];
                                if (!$itemLabel) {
                                    $itemLabel = Yii::$service->page->translate->__($itemName);
                                }
                                $urlInfo = Yii::$service->url->category->getFilterChooseAttrUrl($attrUrlStr, $itemName, 'p');
                                $url = $urlInfo['url'];
                                $selected = $urlInfo['selected'] ? true : false;
                                if ($selected) {
                                    $hasSelected = true;
                                    $selectedVal = $itemLabel;
                                }
                                $attrFilterItem['items'][] = [
                                    '_id' => $itemName,
                                    'label' => $itemLabel, 
                                    'count' => $count, 
                                    'url'=> $url, 
                                    'selected' => $selected,
                                ];
                            } else { // appserver 入口
                                $chosenAttrArr = json_decode($chosenAttrs,true);
                                if(isset($chosenAttrArr[$attr]) && $chosenAttrArr[$attr] == $item['_id']){
                                    $item['selected'] = true;
                                } else {
                                    $item['selected'] = false;
                                }
                                if (!$itemLabel) {
                                    $itemLabel = Yii::$service->page->translate->__($itemName);
                                }
                                $item['label'] = $itemLabel;
                                
                                $attrFilterItem['items'][$k] = $item;
                            }
                        }
                    }
                    if (is_array($attrFilterItem['items']) && !empty($attrFilterItem['items'])) {
                        $attrFilterItem['items'] = array_merge([[
                            '_id' => 'all',
                            'label' => Yii::$service->page->translate->__('All'), 
                            'count' => 0, 
                            'url'=> '', 
                            'selected' => $hasSelected ? false : true,
                        ]], $attrFilterItem['items']);
                        
                        $attrFilterItem['item_selected'] = $selectedVal ;
                        $filter_info[$attr] = $attrFilterItem;
                    }
                    
                }
            }
        }
        // var_dump($filter_info);
        return $filter_info;
    }
    


  
}