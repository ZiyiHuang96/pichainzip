<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */

namespace fecwbbc\services\bdminUser;

use Yii;
use fecshop\services\Service;

/**
 * Order services.
 *
 * @property \fecshop\services\order\Item $item
 *
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class Shipping extends Service
{
    // 模板支付类型：卖家支付运费，免邮
    public $type_cost_bdmin = 'bdmin_shipping_cost';
    // 模板支付类型：买家支付运费
    public $type_cost_customer = 'customer_shipping_cost';
    
   protected $_modelName = '\fecwbbc\models\mysqldb\bdminUser\ShippingTheme';

    protected $_model;
    protected $serializeAttrs = [
        'label',
    ];
    
    public function init()
    {
        parent::init();
        list($this->_modelName, $this->_model) = \Yii::mapGet($this->_modelName);
    }
    
    /**
     * 得到order 表的id字段。
     */
    public function getPrimaryKey()
    {
        return 'id';
    }
    
    /**
     * @param $primaryKey | Int
     * @return Object($this->_orderModel)
     * 通过主键值，返回Order Model对象
     */
    public function getByPrimaryKey($primaryKey)
    {
        $one = $this->_model->findOne($primaryKey);
        $primaryKey = $this->getPrimaryKey();
        if ($one[$primaryKey]) {
            //return $one;
            return $this->unserializeData($one) ;
        } else {
            return new $this->_modelName();
        }
    }
    
    // 保存的数据进行serialize序列化
    protected function serializeSaveData($one) 
    {
        foreach ($one as $k => $v) {
            if (in_array($k, $this->serializeAttrs)) {
                $one[$k] = serialize($v);
            }
        }
        return $one;
    }
    // 保存的数据进行serialize序列化
    protected function unserializeData($one) 
    {
        if (!is_array($one) && !is_object($one)) {
            return $one;
        }
        foreach ($one as $k => $v) {
            if (in_array($k, $this->serializeAttrs)) {
                
                $one[$k] = unserialize($v);
            }
        }
        return $one;
    }
    
    
    public function getLabelByPrimaryKey($primaryKey)
    {
        $shippingM = $this->getByPrimaryKey($primaryKey);
        if (isset($shippingM['label']) && $shippingM['label']) {
            
            return Yii::$service->store->getStoreAttrVal($shippingM['label'], 'label');
        }
        
        return '';
    }
    
    /**
     * @param $filter|array
     * @return Array;
     *              通过过滤条件，得到coupon的集合。
     *              example filter:
     *              [
     *                  'numPerPage' 	=> 20,
     *                  'pageNum'		=> 1,
     *                  'orderBy'	    => ['_id' => SORT_DESC, 'sku' => SORT_ASC ],
     *                  'where'			=> [
     *                      ['>','price',1],
     *                      ['<=','price',10]
     * 			            ['sku' => 'uk10001'],
     * 		            ],
     * 	                'asArray' => true,
     *              ]
     * 根据$filter 搜索参数数组，返回满足条件的订单数据。
     */
    public function coll($filter = '')
    {
        $query  = $this->_model->find();
        $query  = Yii::$service->helper->ar->getCollByFilter($query, $filter);
        $coll   = $query->all();
        $arr = [];
        foreach ($coll as $one) {
            $arr[] = $this->unserializeData($one) ;
        }
        return [
            'coll' => $arr,
            'count'=> $query->limit(null)->offset(null)->count(),
        ];
    }
    
    /**
     * Save the customer info.
     * @param array $param
     * 数据格式如下：
     * ['email' => 'xxx', 'password' => 'xxxx','firstname' => 'xxx','lastname' => 'xxx']
     * @param type | string,  `admin` or `bdmin`
     * @return bool
     * mongodb save system config
     */
    public function save($param)
    {
        $primaryKey = $this->getPrimaryKey();
        $primaryVal = isset($param[$primaryKey]) ? $param[$primaryKey] : '';
        $model = $this->_model;
        $model->attributes = $param;
        // 验证数据。
        if (!$model->validate()) {
            $errors = $model->errors;
            Yii::$service->helper->errors->addByModelErrors($errors);
            
            return false;
        }
            
        if ($primaryVal) {
            $model = $this->getByPrimaryKey($primaryVal);
            if (!$model[$primaryKey]) {
                Yii::$service->helper->errors->add('Shipping Theme {primaryKey} is not exist', ['primaryKey' => $this->getPrimaryKey()]);

                return false;
            } 
        } else {
            $model = new $this->_modelName();
            $model->created_at = time();
        }
        
        $model->updated_at = time();
        unset($param['id']);
        $param = $this->serializeSaveData($param);
        $saveStatus = Yii::$service->helper->ar->save($model, $param);
        if ($saveStatus) {
            
            return $model;
        } else {
            $errors = $model->errors;
            Yii::$service->helper->errors->addByModelErrors($errors);

            return false;
        }
    }
    
    /**
     * remove Static Block.
     */
    public function remove($ids)
    {
        if (!$ids) {
            Yii::$service->helper->errors->add('remove id is empty');

            return false;
        }
        if (is_array($ids) && !empty($ids)) {
            foreach ($ids as $id) {
                $model = $this->_model->findOne($id);
                $model->delete();
            }
        } else {
            $id = $ids;
            $model = $this->_model->findOne($id);
            $model->delete();
        }

        return true;
    }
    
     /**
     * remove Static Block.
     */
    public function removeShippingAndItems($ids, $bdminUserId)
    {
        if (!$ids) {
            Yii::$service->helper->errors->add('remove id is empty');

            return false;
        }
        if (!$bdminUserId) {
            Yii::$service->helper->errors->add('bdminUserId is empty');

            return false;
        }
        if (is_array($ids) && !empty($ids)) {
            foreach ($ids as $id) {
                $model = $this->_model->findOne($id);
                $model->delete();
                Yii::$service->bdminUser->shippingItem->removeByShippingId($id, $bdminUserId );
            }
        } else {
            $id = $ids;
            $model = $this->_model->findOne($id);
            $model->delete();
            Yii::$service->bdminUser->shippingItem->removeByShippingId($id, $bdminUserId );
        }

        return true;
    }
    
    public function getIsDefault($param,$bdminUserId)
    {
        $is_default = (int)$param['is_default'];
        
        if ($is_default != 1 && $is_default != 2) {
            $is_default  = 2;
        }
        // 判断是否存在默认的shipping方式
        $findOneWhere = [];
        if (!$param['id']) {
            $findOneWhere = [
                'bdmin_user_id' => $bdminUserId,
                'is_default' => 1,
            ];
        } else {
            $findOneWhere = [
                'and',
                [
                    'bdmin_user_id' => $bdminUserId,
                    'is_default' => 1,
                ],
                ['<>', 'id', $param['id']],
            ];
        }
        $defaultM = $this->_model->findOne($findOneWhere);
        if (!$defaultM) {
            $is_default  = 1;
        }
        
        return $is_default ;
    }
    /**
     * @param $param | array, 保存的数组
     * 保存shipping的数据，以及保存默认所有国家的运费区间数据
     */
    public function saveShipping($param)
    {
        $bdminUserId = $param['bdmin_user_id'];
        $label = $param['label'];
        
        $is_default = $this->getIsDefault($param,$bdminUserId);
        
        if (!$label || !is_array($label) || empty($label)) {
            Yii::$service->helper->errors->add('shipping label can not empty');
            
            return false;
        }
        if (!$bdminUserId) {
            Yii::$service->helper->errors->add('bdminUserId can not empty');
            
            return false;
        }
        // 保存shipping
        $saveData = [
            'bdmin_user_id' => $bdminUserId,
            'label' => $label,
            'is_default' => $is_default ,
        ];
        if ($param['id']) {
            $saveData['id'] = $param['id'];
        }
        
        $shippingM = $this->save($saveData);
        if ($is_default == 1) {
            $this->_model->updateAll(
                [
                    'is_default' => 2,
                ],
                [
                    'and',
                    ['bdmin_user_id' => $bdminUserId],
                    ['<>', 'id', $shippingM['id']],
                ]
            );
        }
        $shippingId = $shippingM['id'];
        // 保存shipping Items
        $shipping_info = $param['shipping_info'];
        if (is_array($shipping_info) && !empty($shipping_info)) {
            $saveItemData = [
                'bdmin_shipping_id' => $shippingId,
                'country_codes' => Yii::$service->bdminUser->shippingItem->defaultCountryCodeStr,
                'shipping_info' => $shipping_info,
                'bdmin_user_id' => $bdminUserId,
                
            ];
            if (!Yii::$service->bdminUser->shippingItem->saveDefaultShippingItem($saveItemData)) {
                
                return false;
            }
        }
        
        return true;
    }
    
    
    
    public function getThemesByBdminUserId($bdmin_user_id) 
    {
        $filter = [
            'where' => [
                ['bdmin_user_id' => $bdmin_user_id]
            ],
            'fetchAll' => true,
        ];
        $data = $this->coll($filter);
        $coll = $data['coll'];
        $arr = [];
        if (is_array($coll)) {
            foreach ($coll as $one) {
                $_id = (string)$one['id'];
                $arr[$_id] =  Yii::$service->fecshoplang->getDefaultLangAttrVal($one['label'], 'label');
            }
        }
        
        return $arr;
    }
    
    public function getBdminDefaultShippingMethod($bdmin_user_id)
    {
        $one = $this->_model->findOne(['bdmin_user_id' => $bdmin_user_id, 'is_default' => 1]);
        // 如果存在设置的 'is_default' => 1
        if (isset($one[$this->getPrimaryKey()]) && $one[$this->getPrimaryKey()]) {
            
            return (string)$one[$this->getPrimaryKey()];
        }
        // 如果不存在，则取第一个为默认
        $one = $this->_model->findOne(['bdmin_user_id' => $bdmin_user_id]);
        if (isset($one[$this->getPrimaryKey()]) && $one[$this->getPrimaryKey()]) {
            
            return (string)$one[$this->getPrimaryKey()];
        }
        
        return null;
    }
    
    
    
}