<?php
/**
 * FecMall file.
 *
 * @link http://www.fecmall.com/
 * @copyright Copyright (c) 2016 FecMall Software LLC
 * @license http://www.fecmall.com/license
 */

namespace fecwbbc\models\mysqldb\bdminUser;

use yii\db\ActiveRecord;

/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class ShippingItem extends ActiveRecord
{
    public static function tableName()
    {
        return '{{%bdmin_shipping_items}}';
    }
    
    public function rules()
    {
        return [
            ['bdmin_user_id', 'trim'],
            ['bdmin_shipping_id', 'trim'],
            ['country_codes', 'trim'],
            ['shipping_info', 'trim'],
            
        ];
    }
    
}
