#!/bin/sh
Cur_Dir=$(cd `dirname $0`; pwd)
# get product all count.
$Cur_Dir/../../../../../yii order/product/returnpendingstock








