$(document).ready(function(){
    $(".app-header-left .showMenu").click(function(){
        $(".js-side-nav.side-nav").addClass("side-nav--visible");
        $(".js-side-nav-container").css({left:"-8rem"});
        $(".js-side-nav-container").animate({left:"0"},400);
    });
    
    $(".js-side-nav.side-nav").click(function(){
        $(".js-side-nav.side-nav").removeClass("side-nav--visible");
        
    });
    $(".js-side-nav-container").click(function(e){
        e.stopPropagation();
    });
    
    $("body").on("click", ".span_click", function(){
        url = $(this).attr('rel');
        window.location.href = url;
    });
    
    $(".span_click").click(function(){
        url = $(this).attr('rel');
        window.location.href = url;
    });
    
});