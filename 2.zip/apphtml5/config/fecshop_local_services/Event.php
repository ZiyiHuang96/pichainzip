<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 *
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    'event' => [
        'eventList' => [
            /*
            # 加入购物车前
            'event_add_to_cart_before' => [
                ['apphtml5\event\CartTest1','beforeAdd1'],
                ['apphtml5\event\CartTest2','beforeAdd2'],
            ],
            */
        ],

    ],
];
