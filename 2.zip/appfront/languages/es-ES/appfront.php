<?php

return [
 'fecshop'  => 'es_ES fecshop',
];
