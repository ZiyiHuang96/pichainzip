<?php

return [
 'fecshop'            => 'fr_FR app developer fecshop',
 'fecshop,{username}' => 'fr_FR 22 app fecshop,{username}',
];
