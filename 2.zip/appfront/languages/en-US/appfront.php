<?php

return [
 'fecshop'  => 'en_US fecshop',
];
