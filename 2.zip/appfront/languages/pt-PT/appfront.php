<?php

return [
 'fecshop'  => 'pt_PT fecshop',
];
