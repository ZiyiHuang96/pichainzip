<?php

return [
 'fecshop'  => 'nl_NL fecshop',
];
