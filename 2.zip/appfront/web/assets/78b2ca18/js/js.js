$(document).ready(function(){
	//logoutUrl 	 = $(".logoutUrl").val();
	product_id   = $(".product_view_id").val();
	product_id	 = product_id ? product_id : null;
    
    
    currentBaseUrl = $(".currentBaseUrl").val();
    loginInfoUrl = currentBaseUrl+"/customer/ajax";
    if (currentBaseUrl) {
        $.ajax({
            async:true,
            timeout: 6000,
            dataType: 'json', 
            type:'get',
            data: {
                'currentUrl':window.location.href,
                'product_id':product_id
            },
            url:loginInfoUrl,
            success:function(data, textStatus){ 
                //welcome = $('.welcome_str').val();
                //logoutStr = $('.logoutStr').val();
                if(data.loginStatus){
                    $(".header-right-user__register-guide").hide();
                    $(".header-right-user__user-info").show();
                }
                //if(data.favorite){
                //	$(".myFavorite_nohove").addClass("act");
                //	$(".myFavorite_nohove a").addClass("act");
                //}
                if(data.favorite_product_count){
                    $(".header-right-user-wishlist-num-js").html(data.favorite_product_count);
                }
                //if(data.csrfName && data.csrfVal && data.product_id){
                //	$(".product_csrf").attr("name",data.csrfName);
                //	$(".product_csrf").val(data.csrfVal);
                //}
                if(data.cart_qty){
                    $(".header-right-user-bag-num").html(data.cart_qty);
                }
                
                
            },
            error:function (XMLHttpRequest, textStatus, errorThrown){}
        });
        
        $(".top_currency .currency_list ul li").click(function(){
            currency = $(this).attr("rel");
            
            htmlobj=$.ajax({url:currentBaseUrl+"/cms/home/changecurrency?currency="+currency,async:false});
            //alert(htmlobj.responseText);
            location.reload() ;
        });
    }
    
	$(".top_lang .store_lang").click(function(){
		//http = document.location.protocol+"://";
		currentStore = $(".current_lang").attr("rel");
		changeStore = $(this).attr("rel");
		currentUrl = window.location.href;
		redirectUrl = currentUrl.replace("://"+currentStore,"://"+changeStore);
		//alert(redirectUrl);
		//alert(2);
		location.href=redirectUrl;
	});
	
	// ajax get account login info
	
	
	
	$("#goTop").click(function(){
		$("html,body").animate({scrollTop:0},"slow");
	});
	
	$("#goBottom").click(function(){
		var screenb = $(document).height();
		$("html,body").animate({scrollTop:screenb},"slow");
	});
	
});

function doPost(to, p) { // to:提交动作（action）,p:参数
    var myForm = document.createElement("form");
    myForm.method = "post";
    myForm.action = to;
    for (var i in p){
        var myInput = document.createElement("input");
        myInput.setAttribute("name", i); // 为input对象设置name
        myInput.setAttribute("value", p[i]); // 为input对象设置value
        myForm.appendChild(myInput);
    }
    document.body.appendChild(myForm);
    myForm.submit();
    document.body.removeChild(myForm); // 提交后移除创建的form
}

