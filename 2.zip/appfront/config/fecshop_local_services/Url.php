<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 *
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    'url' => [
        'showScriptName'=> false, // if is show index.php in url.  if set false ,you must config nginx rewrite
    ],
];
