<?php
   return [
   'store' => [
        //'class'  => 'fecshop\services\Store',
        

    ],

];
