<?php
namespace appfront\local\local_models\mongodb;

use yii\mongodb\ActiveRecord;

class Category extends \fecshop\models\mongodb\Category
{
    
}