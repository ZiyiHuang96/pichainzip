<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace appfront\local\local_modules\Catalog\block\product;

use Yii;

/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class CustomOption extends \fecshop\app\appfront\modules\Catalog\block\product\CustomOption
{
    public function getLastData()
    {
        /*
        $items = $this->getAllItems();
        //var_dump($items);exit;
        return [
            'items' => $items,
            'product_id'        => $this->product_id,
            'custom_option_arr' => json_encode($this->_custom_option_arr),
            'middle_img_width'  => $this->middle_img_width,
        ];
        */
        
    }
    
    

    
    
    
    
}















