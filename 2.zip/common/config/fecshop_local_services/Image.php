<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 *
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    'image' => [
        // 图片对应的文件路径
        'commonBaseDir' => '@appimage/common',
        // 'commonBaseDomain' => '//img.fancyecommerce.com',
        /*
        'appbase'    => [
            'common' => [
                'basedir'    => 
                //'basedomain' => '//img.fancyecommerce.com',
            ],
        ],
        */
    ],
];
